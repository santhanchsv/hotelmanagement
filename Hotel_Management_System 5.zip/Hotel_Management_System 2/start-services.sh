#!/bin/bash

# Hotel Management System - Microservices Startup Script

echo "Starting Hotel Management System Microservices..."

# Function to start a service
start_service() {
    local service_name=$1
    local port=$2
    local directory=$3
    
    echo "Starting $service_name on port $port..."
    cd "$directory"
    mvn spring-boot:run > "../logs/${service_name}.log" 2>&1 &
    local pid=$!
    echo "$service_name started with PID: $pid"
    echo $pid > "../logs/${service_name}.pid"
    cd ..
    
    # Wait a bit before starting next service
    sleep 10
}

# Create logs directory
mkdir -p logs

echo "Creating logs directory..."

# Start services in order
echo "1. Starting Discovery Server (Eureka)..."
start_service "discovery-server" "8761" "discovery-server"

echo "2. Starting API Gateway..."
start_service "api-gateway" "8088" "api-gateway"

echo "3. Starting Catalog Service..."
start_service "catalog-service" "8092" "catalog-service"

echo "4. Starting User Service..."
start_service "user-service" "8094" "user-service"

echo "5. Starting Booking Service..."
start_service "booking-service" "8093" "booking-service"

echo ""
echo "All services are starting up..."
echo "Please wait 2-3 minutes for all services to be ready."
echo ""
echo "Service URLs:"
echo "- Eureka Dashboard: http://localhost:8761"
echo "- API Gateway: http://localhost:8088"
echo "- Catalog Service: http://localhost:8092"
echo "- User Service: http://localhost:8094"
echo "- Booking Service: http://localhost:8093"
echo ""
echo "H2 Console URLs:"
echo "- Catalog Service: http://localhost:8092/h2"
echo "- User Service: http://localhost:8094/h2"
echo "- Booking Service: http://localhost:8093/h2"
echo ""
echo "To stop all services, run: ./stop-services.sh"
echo "To view logs, check the logs/ directory"
