package com.ilpmum.hotel.catalog_service.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ilpmum.hotel.catalog_service.model.Hotel;

public interface HotelRepository extends JpaRepository<Hotel, Long> {
	
	boolean existsByNameIgnoreCaseAndCityIgnoreCase(String name, String city);
	boolean existsByNameIgnoreCaseAndCityIgnoreCaseAndHotelIdNot(String name, String city, Long hotelId);
	
	// Find hotels by status
	List<Hotel> findByStatus(Hotel.HotelStatus status);
	
	// Find hotels by city
	List<Hotel> findByCityIgnoreCase(String city);
	
	// Find hotels by rating range
	List<Hotel> findByRatingGreaterThanEqual(Double minRating);
	
	// Find available hotels (with available rooms)
	List<Hotel> findByAvailableRoomsGreaterThan(Integer minAvailableRooms);
}
