package com.ilpmum.hotel.catalog_service.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "room_type")
public class RoomType {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long roomTypeId;
	
	@ManyToOne(optional = false)
	@JoinColumn(name = "hotel_id")
	private Hotel hotel;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private Category category;
	
	@Column(nullable = false)
	private String description;
	
	@Column(nullable = false)
	private Integer capacity;
	
	@Column(nullable = false)
	private Double pricePerDay;
	
	@ElementCollection
	@CollectionTable(name = "room_type_amenities", joinColumns = @JoinColumn(name = "room_type_id"))
	@Column(name = "amenity")
	private List<String> amenities;
	
	@OneToMany(mappedBy = "roomType", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Room> rooms;
	
	// Constructors
	public RoomType() {
		super();
	}

	public RoomType(Hotel hotel, Category category, String description, Integer capacity, Double pricePerDay, List<String> amenities) {
		this.hotel = hotel;
		this.category = category;
		this.description = description;
		this.capacity = capacity;
		this.pricePerDay = pricePerDay;
		this.amenities = amenities;
	}

	// Getters and Setters
	public Long getRoomTypeId() {
		return roomTypeId;
	}

	public void setRoomTypeId(Long roomTypeId) {
		this.roomTypeId = roomTypeId;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getCapacity() {
		return capacity;
	}

	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}

	public Double getPricePerDay() {
		return pricePerDay;
	}

	public void setPricePerDay(Double pricePerDay) {
		this.pricePerDay = pricePerDay;
	}

	public List<String> getAmenities() {
		return amenities;
	}

	public void setAmenities(List<String> amenities) {
		this.amenities = amenities;
	}

	public List<Room> getRooms() {
		return rooms;
	}

	public void setRooms(List<Room> rooms) {
		this.rooms = rooms;
	}

	public enum Category {
		STANDARD, DELUXE, SUITE
	}
}
