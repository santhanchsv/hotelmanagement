package com.ilpmum.hotel.catalog_service.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(
		name = "rooms",
		uniqueConstraints = @UniqueConstraint(
				name = "uk_room_hotel_number",
				columnNames = {"hotel_id", "room_number"}
				)
		)
public class Room {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long roomId;
	
	@ManyToOne(optional = false)
	@JoinColumn(name = "hotel_id")
	private Hotel hotel;
	
	@ManyToOne(optional = false)
	@JoinColumn(name = "room_type_id")
	private RoomType roomType;
	
	@Column(nullable = false)
	private String roomNumber;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private RoomStatus status;
	
	@Column(nullable = false)
	private Integer floorNumber;
	
	private LocalDate lastMaintenanceDate;
	
	// Constructors
	public Room() {
		super();
	}

	public Room(Hotel hotel, RoomType roomType, String roomNumber, RoomStatus status, Integer floorNumber, LocalDate lastMaintenanceDate) {
		this.hotel = hotel;
		this.roomType = roomType;
		this.roomNumber = roomNumber;
		this.status = status;
		this.floorNumber = floorNumber;
		this.lastMaintenanceDate = lastMaintenanceDate;
	}

	// Getters and Setters
	public Long getRoomId() {
		return roomId;
	}

	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public RoomType getRoomType() {
		return roomType;
	}

	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public RoomStatus getStatus() {
		return status;
	}

	public void setStatus(RoomStatus status) {
		this.status = status;
	}

	public Integer getFloorNumber() {
		return floorNumber;
	}

	public void setFloorNumber(Integer floorNumber) {
		this.floorNumber = floorNumber;
	}

	public LocalDate getLastMaintenanceDate() {
		return lastMaintenanceDate;
	}

	public void setLastMaintenanceDate(LocalDate lastMaintenanceDate) {
		this.lastMaintenanceDate = lastMaintenanceDate;
	}

	public enum RoomStatus {
		AVAILABLE, RESERVED, OCCUPIED, UNDER_MAINTENANCE
	}

}
