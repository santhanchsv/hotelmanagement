package com.ilpmum.hotel.catalog_service.service;

import com.ilpmum.hotel.catalog_service.model.Hotel;
import com.ilpmum.hotel.catalog_service.model.Room;
import com.ilpmum.hotel.catalog_service.model.RoomType;
import com.ilpmum.hotel.catalog_service.repo.HotelRepository;
import com.ilpmum.hotel.catalog_service.repo.RoomRepository;
import com.ilpmum.hotel.catalog_service.repo.RoomTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class CatalogService {
    
    private final HotelRepository hotelRepository;
    private final RoomTypeRepository roomTypeRepository;
    private final RoomRepository roomRepository;
    
    public CatalogService(HotelRepository hotelRepository, 
                         RoomTypeRepository roomTypeRepository,
                         RoomRepository roomRepository) {
        this.hotelRepository = hotelRepository;
        this.roomTypeRepository = roomTypeRepository;
        this.roomRepository = roomRepository;
    }
    
    // Hotel operations
    public List<Hotel> getAllHotels() {
        return hotelRepository.findAll();
    }
    
    public Optional<Hotel> getHotelById(Long hotelId) {
        return hotelRepository.findById(hotelId);
    }
    
    public Hotel createHotel(Hotel hotel) {
        if (hotelRepository.existsByNameIgnoreCaseAndCityIgnoreCase(hotel.getName(), hotel.getCity())) {
            throw new IllegalArgumentException("A hotel with the same name in this city already exists");
        }
        
        if (hotel.getStatus() == null) {
            hotel.setStatus(Hotel.HotelStatus.OPEN);
        }
        if (hotel.getTotalRooms() == null) {
            hotel.setTotalRooms(0);
        }
        if (hotel.getAvailableRooms() == null) {
            hotel.setAvailableRooms(0);
        }
        
        return hotelRepository.save(hotel);
    }
    
    public Hotel updateHotel(Long hotelId, Hotel updatedHotel) {
        return hotelRepository.findById(hotelId)
                .map(existing -> {
                    existing.setName(updatedHotel.getName());
                    existing.setCity(updatedHotel.getCity());
                    existing.setAddress(updatedHotel.getAddress());
                    existing.setStatus(updatedHotel.getStatus());
                    existing.setRating(updatedHotel.getRating());
                    existing.setTotalRooms(updatedHotel.getTotalRooms());
                    existing.setAvailableRooms(updatedHotel.getAvailableRooms());
                    return hotelRepository.save(existing);
                })
                .orElseThrow(() -> new IllegalArgumentException("Hotel not found"));
    }
    
    public void deleteHotel(Long hotelId) {
        Hotel hotel = hotelRepository.findById(hotelId)
                .orElseThrow(() -> new IllegalArgumentException("Hotel not found"));
        
        if (hotel.getStatus() != Hotel.HotelStatus.CLOSED) {
            throw new IllegalArgumentException("Hotel must be set to CLOSED before deletion");
        }
        
        roomTypeRepository.deleteByHotelId(hotelId);
        hotelRepository.delete(hotel);
    }
    
    public List<Hotel> getHotelsByStatus(Hotel.HotelStatus status) {
        return hotelRepository.findByStatus(status);
    }
    
    public List<Hotel> getHotelsByCity(String city) {
        return hotelRepository.findByCityIgnoreCase(city);
    }
    
    public List<Hotel> getHotelsByRating(Double minRating) {
        return hotelRepository.findByRatingGreaterThanEqual(minRating);
    }
    
    // RoomType operations
    public List<RoomType> getAllRoomTypes() {
        return roomTypeRepository.findAll();
    }
    
    public Optional<RoomType> getRoomTypeById(Long roomTypeId) {
        return roomTypeRepository.findById(roomTypeId);
    }
    
    public List<RoomType> getRoomTypesByHotel(Long hotelId) {
        return roomTypeRepository.findByHotelHotelId(hotelId);
    }
    
    public RoomType createRoomType(RoomType roomType) {
        return roomTypeRepository.save(roomType);
    }
    
    public RoomType updateRoomType(Long roomTypeId, RoomType updatedRoomType) {
        return roomTypeRepository.findById(roomTypeId)
                .map(existing -> {
                    existing.setCategory(updatedRoomType.getCategory());
                    existing.setDescription(updatedRoomType.getDescription());
                    existing.setCapacity(updatedRoomType.getCapacity());
                    existing.setPricePerDay(updatedRoomType.getPricePerDay());
                    existing.setAmenities(updatedRoomType.getAmenities());
                    return roomTypeRepository.save(existing);
                })
                .orElseThrow(() -> new IllegalArgumentException("RoomType not found"));
    }
    
    public void deleteRoomType(Long roomTypeId) {
        if (!roomTypeRepository.existsById(roomTypeId)) {
            throw new IllegalArgumentException("RoomType not found");
        }
        roomTypeRepository.deleteById(roomTypeId);
    }
    
    public List<RoomType> getRoomTypesByCategory(RoomType.Category category) {
        return roomTypeRepository.findByCategory(category);
    }
    
    public List<RoomType> getRoomTypesByPriceRange(Double minPrice, Double maxPrice) {
        return roomTypeRepository.findByPricePerDayBetween(minPrice, maxPrice);
    }
    
    // Room operations
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }
    
    public Optional<Room> getRoomById(Long roomId) {
        return roomRepository.findById(roomId);
    }
    
    public List<Room> getRoomsByHotel(Long hotelId) {
        return roomRepository.findByHotelHotelId(hotelId);
    }
    
    public List<Room> getAvailableRooms() {
        return roomRepository.findByStatus(Room.RoomStatus.AVAILABLE);
    }
    
    public List<Room> getRoomsByHotelAndStatus(Long hotelId, Room.RoomStatus status) {
        return roomRepository.findByHotelHotelIdAndStatus(hotelId, status);
    }
    
    public Room createRoom(Room room) {
        return roomRepository.save(room);
    }
    
    public Room updateRoom(Long roomId, Room updatedRoom) {
        return roomRepository.findById(roomId)
                .map(existing -> {
                    existing.setRoomNumber(updatedRoom.getRoomNumber());
                    existing.setStatus(updatedRoom.getStatus());
                    existing.setFloorNumber(updatedRoom.getFloorNumber());
                    existing.setLastMaintenanceDate(updatedRoom.getLastMaintenanceDate());
                    return roomRepository.save(existing);
                })
                .orElseThrow(() -> new IllegalArgumentException("Room not found"));
    }
    
    public void deleteRoom(Long roomId) {
        if (!roomRepository.existsById(roomId)) {
            throw new IllegalArgumentException("Room not found");
        }
        roomRepository.deleteById(roomId);
    }
    
    public Room updateRoomStatus(Long roomId, Room.RoomStatus status) {
        return roomRepository.findById(roomId)
                .map(room -> {
                    room.setStatus(status);
                    return roomRepository.save(room);
                })
                .orElseThrow(() -> new IllegalArgumentException("Room not found"));
    }
    
    public List<Room> getRoomsNeedingMaintenance() {
        return roomRepository.findByStatusAndLastMaintenanceDateBefore(
                Room.RoomStatus.AVAILABLE, LocalDate.now().minusMonths(6));
    }
    
    public void updateRoomMaintenanceDate(Long roomId) {
        roomRepository.findById(roomId)
                .ifPresent(room -> {
                    room.setLastMaintenanceDate(LocalDate.now());
                    roomRepository.save(room);
                });
    }
    
    // Business logic methods
    public void updateHotelRoomCounts(Long hotelId) {
        Hotel hotel = hotelRepository.findById(hotelId)
                .orElseThrow(() -> new IllegalArgumentException("Hotel not found"));
        
        long totalRooms = roomRepository.countByRoomTypeRoomTypeId(hotelId);
        long availableRooms = roomRepository.findByHotelHotelIdAndStatus(hotelId, Room.RoomStatus.AVAILABLE).size();
        
        hotel.setTotalRooms((int) totalRooms);
        hotel.setAvailableRooms((int) availableRooms);
        hotelRepository.save(hotel);
    }
    
    public boolean isRoomAvailable(Long roomId, LocalDate checkInDate, LocalDate checkOutDate) {
        // This would typically check against booking service
        // For now, just check room status
        return roomRepository.findById(roomId)
                .map(room -> room.getStatus() == Room.RoomStatus.AVAILABLE)
                .orElse(false);
    }
}
