package com.ilpmum.hotel.catalog_service.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(
		name = "hotel",
		uniqueConstraints = @UniqueConstraint(columnNames = {"name", "city"})
		)
public class Hotel {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long hotelId;
	
	@Column(nullable = false)
	private String name;
	@Column(nullable = false)
	private String city;
	private String address;
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private HotelStatus status;
	
	private Double rating;
	private Integer totalRooms;
	private Integer availableRooms;
	
	@OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<RoomType> roomTypes;
	
	@OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<Room> rooms;
	
	
	// Constructors
	public Hotel() {
		super();
	}

	public Hotel(String name, String city, String address, HotelStatus status, Double rating, Integer totalRooms, Integer availableRooms) {
		this.name = name;
		this.city = city;
		this.address = address;
		this.status = status;
		this.rating = rating;
		this.totalRooms = totalRooms;
		this.availableRooms = availableRooms;
	}

	// Getters and Setters
	public Long getHotelId() {
		return hotelId;
	}

	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}

	// Alias for getHotelId() for backward compatibility
	public Long getId() {
		return hotelId;
	}

	public void setId(Long id) {
		this.hotelId = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public HotelStatus getStatus() {
		return status;
	}

	public void setStatus(HotelStatus status) {
		this.status = status;
	}

	public Double getRating() {
		return rating;
	}

	public void setRating(Double rating) {
		this.rating = rating;
	}

	public Integer getTotalRooms() {
		return totalRooms;
	}

	public void setTotalRooms(Integer totalRooms) {
		this.totalRooms = totalRooms;
	}

	public Integer getAvailableRooms() {
		return availableRooms;
	}

	public void setAvailableRooms(Integer availableRooms) {
		this.availableRooms = availableRooms;
	}

	public List<RoomType> getRoomTypes() {
		return roomTypes;
	}

	public void setRoomTypes(List<RoomType> roomTypes) {
		this.roomTypes = roomTypes;
	}

	public List<Room> getRooms() {
		return rooms;
	}

	public void setRooms(List<Room> rooms) {
		this.rooms = rooms;
	}

	public enum HotelStatus {
		OPEN, CLOSED, UNDER_MAINTENANCE
	}
}
