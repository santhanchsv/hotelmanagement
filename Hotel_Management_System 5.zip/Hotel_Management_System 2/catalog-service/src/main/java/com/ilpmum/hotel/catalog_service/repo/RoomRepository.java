package com.ilpmum.hotel.catalog_service.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ilpmum.hotel.catalog_service.model.Room;

public interface RoomRepository extends JpaRepository<Room, Long> {
	
	List<Room> findByHotelHotelId(Long hotelId);
	List<Room> findByHotelHotelIdAndStatus(Long hotelId, Room.RoomStatus status);
	List<Room> findByRoomTypeRoomTypeId(Long roomTypeId);
	List<Room> findByHotelHotelIdAndRoomTypeRoomTypeId(Long hotelId, Long roomTypeId);
	long countByRoomTypeRoomTypeId(Long roomTypeId);
	
	// Find available rooms
	List<Room> findByStatus(Room.RoomStatus status);
	
	// Find rooms by floor
	List<Room> findByHotelHotelIdAndFloorNumber(Long hotelId, Integer floorNumber);
	
	// Find rooms needing maintenance
	List<Room> findByStatusAndLastMaintenanceDateBefore(Room.RoomStatus status, java.time.LocalDate date);

}
