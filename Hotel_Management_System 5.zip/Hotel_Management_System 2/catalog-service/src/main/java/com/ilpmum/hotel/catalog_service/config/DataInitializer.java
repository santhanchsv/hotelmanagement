package com.ilpmum.hotel.catalog_service.config;

import com.ilpmum.hotel.catalog_service.model.Hotel;
import com.ilpmum.hotel.catalog_service.model.Room;
import com.ilpmum.hotel.catalog_service.model.RoomType;
import com.ilpmum.hotel.catalog_service.repo.HotelRepository;
import com.ilpmum.hotel.catalog_service.repo.RoomRepository;
import com.ilpmum.hotel.catalog_service.repo.RoomTypeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {
    
    private final HotelRepository hotelRepository;
    private final RoomTypeRepository roomTypeRepository;
    private final RoomRepository roomRepository;
    
    public DataInitializer(HotelRepository hotelRepository, 
                          RoomTypeRepository roomTypeRepository,
                          RoomRepository roomRepository) {
        this.hotelRepository = hotelRepository;
        this.roomTypeRepository = roomTypeRepository;
        this.roomRepository = roomRepository;
    }
    
    @Override
    public void run(String... args) throws Exception {
        // Initialize sample data
        initializeSampleData();
    }
    
    private void initializeSampleData() {
        // Create sample hotels
        Hotel hotel1 = new Hotel("Grand Palace Hotel", "Mumbai", "123 Marine Drive, Mumbai", 
                                Hotel.HotelStatus.OPEN, 4.5, 50, 45);
        Hotel hotel2 = new Hotel("Royal Garden Resort", "Delhi", "456 Connaught Place, Delhi", 
                                Hotel.HotelStatus.OPEN, 4.2, 30, 28);
        Hotel hotel3 = new Hotel("Seaside Paradise", "Goa", "789 Beach Road, Goa", 
                                Hotel.HotelStatus.OPEN, 4.8, 25, 20);
        
        hotel1 = hotelRepository.save(hotel1);
        hotel2 = hotelRepository.save(hotel2);
        hotel3 = hotelRepository.save(hotel3);
        
        // Create room types for hotel1
        RoomType standard1 = new RoomType(hotel1, RoomType.Category.STANDARD, 
                                         "Comfortable room with city view", 2, 2500.0, 
                                         Arrays.asList("WiFi", "AC", "TV", "Mini Bar"));
        RoomType deluxe1 = new RoomType(hotel1, RoomType.Category.DELUXE, 
                                       "Spacious room with sea view", 3, 4500.0, 
                                       Arrays.asList("WiFi", "AC", "TV", "Mini Bar", "Balcony", "Room Service"));
        RoomType suite1 = new RoomType(hotel1, RoomType.Category.SUITE, 
                                      "Luxury suite with panoramic view", 4, 8000.0, 
                                      Arrays.asList("WiFi", "AC", "TV", "Mini Bar", "Balcony", "Room Service", "Jacuzzi", "Butler Service"));
        
        standard1 = roomTypeRepository.save(standard1);
        deluxe1 = roomTypeRepository.save(deluxe1);
        suite1 = roomTypeRepository.save(suite1);
        
        // Create room types for hotel2
        RoomType standard2 = new RoomType(hotel2, RoomType.Category.STANDARD, 
                                         "Cozy room with garden view", 2, 2000.0, 
                                         Arrays.asList("WiFi", "AC", "TV"));
        RoomType deluxe2 = new RoomType(hotel2, RoomType.Category.DELUXE, 
                                       "Elegant room with city view", 3, 3500.0, 
                                       Arrays.asList("WiFi", "AC", "TV", "Mini Bar", "Balcony"));
        
        standard2 = roomTypeRepository.save(standard2);
        deluxe2 = roomTypeRepository.save(deluxe2);
        
        // Create room types for hotel3
        RoomType standard3 = new RoomType(hotel3, RoomType.Category.STANDARD, 
                                         "Beach view room", 2, 3000.0, 
                                         Arrays.asList("WiFi", "AC", "TV", "Beach Access"));
        RoomType deluxe3 = new RoomType(hotel3, RoomType.Category.DELUXE, 
                                       "Ocean view room with balcony", 3, 5500.0, 
                                       Arrays.asList("WiFi", "AC", "TV", "Mini Bar", "Balcony", "Beach Access", "Room Service"));
        
        standard3 = roomTypeRepository.save(standard3);
        deluxe3 = roomTypeRepository.save(deluxe3);
        
        // Create sample rooms for hotel1
        createRoomsForHotel(hotel1, standard1, 10, "101-110");
        createRoomsForHotel(hotel1, deluxe1, 8, "201-208");
        createRoomsForHotel(hotel1, suite1, 2, "301-302");
        
        // Create sample rooms for hotel2
        createRoomsForHotel(hotel2, standard2, 15, "101-115");
        createRoomsForHotel(hotel2, deluxe2, 10, "201-210");
        
        // Create sample rooms for hotel3
        createRoomsForHotel(hotel3, standard3, 12, "101-112");
        createRoomsForHotel(hotel3, deluxe3, 8, "201-208");
    }
    
    private void createRoomsForHotel(Hotel hotel, RoomType roomType, int count, String roomNumberPattern) {
        String[] roomNumbers = roomNumberPattern.split("-");
        int startNum = Integer.parseInt(roomNumbers[0]);
        int endNum = Integer.parseInt(roomNumbers[1]);
        
        for (int i = startNum; i <= endNum && i < startNum + count; i++) {
            Room room = new Room(hotel, roomType, String.valueOf(i), 
                               Room.RoomStatus.AVAILABLE, 
                               i / 100, // floor number
                               LocalDate.now().minusMonths(2)); // last maintenance
            roomRepository.save(room);
        }
    }
}
