package com.ilpmum.hotel.catalog_service.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ilpmum.hotel.catalog_service.model.RoomType;

public interface RoomTypeRepository extends JpaRepository<RoomType, Long> {
	
	List<RoomType> findByHotelHotelId(Long hotelId);
	Optional<RoomType> findByRoomTypeIdAndHotelHotelId(Long roomTypeId, Long hotelId);
	List<RoomType> findByHotelHotelIdAndCategory(Long hotelId, RoomType.Category category);
	List<RoomType> findByCategory(RoomType.Category category);
	List<RoomType> findByPricePerDayBetween(Double minPrice, Double maxPrice);
	List<RoomType> findByCapacityGreaterThanEqual(Integer minCapacity);
	
	// Find room types by amenities
	List<RoomType> findByAmenitiesContaining(String amenity);
	
	// Delete room types by hotel ID
	void deleteByHotelHotelId(Long hotelId);
	
}
