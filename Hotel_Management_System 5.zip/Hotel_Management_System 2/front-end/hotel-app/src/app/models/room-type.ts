export interface RoomType {
  roomTypeId?: number;
  hotelId?: number;
  category: 'STANDARD' | 'DELUXE' | 'SUITE';
  description: string;
  capacity: number;
  pricePerDay: number;
  amenities: string[];
}