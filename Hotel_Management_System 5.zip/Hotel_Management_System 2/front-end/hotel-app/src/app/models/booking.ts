export interface Booking {
  bookingId?: number;
  userId: number;
  hotelId: number;
  roomId: number;
  checkInDate: string;
  checkOutDate: string;
  status: 'PENDING' | 'CONFIRMED' | 'CHECKED_IN' | 'CHECKED_OUT' | 'CANCELLED';
  totalAmount: number;
  paymentStatus: 'PAID' | 'UNPAID' | 'REFUNDED';
  reservationDate?: string;
  specialRequests?: string;
  checkInTime?: string;
  checkOutTime?: string;
  numberOfGuests?: number;
  createdAt?: Date;
  updatedAt?: Date;
  // Related entities for display
  hotel?: {
    name: string;
    city: string;
    address?: string;
  };
  room?: {
    roomNumber: string;
    roomType?: {
      category: string;
      capacity: number;
    };
  };
  user?: {
    firstName: string;
    lastName: string;
    email: string;
  };
}

export interface BookingRequest {
  userId: number;
  hotelId: number;
  roomId: number;
  checkInDate: string;
  checkOutDate: string;
  numberOfGuests?: number;
  specialRequests?: string;
}

export interface BookingSummary {
  bookingId: number;
  hotelName: string;
  roomNumber: string;
  checkInDate: string;
  checkOutDate: string;
  status: 'PENDING' | 'CONFIRMED' | 'CHECKED_IN' | 'CHECKED_OUT' | 'CANCELLED';
  totalAmount: number;
  paymentStatus: 'PAID' | 'UNPAID' | 'REFUNDED';
  numberOfNights: number;
}

export interface BookingFilters {
  userId?: number;
  hotelId?: number;
  status?: 'PENDING' | 'CONFIRMED' | 'CHECKED_IN' | 'CHECKED_OUT' | 'CANCELLED';
  paymentStatus?: 'PAID' | 'UNPAID' | 'REFUNDED';
  checkInDateFrom?: Date;
  checkInDateTo?: Date;
  checkOutDateFrom?: Date;
  checkOutDateTo?: Date;
}
