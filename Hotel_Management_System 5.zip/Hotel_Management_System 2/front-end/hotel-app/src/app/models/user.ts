export interface User {
  userId?: number;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  passwordHash?: string;
  role: 'CUSTOMER' | 'STAFF' | 'ADMIN';
  loyaltyPoints?: number;
  dateOfBirth?: string;
  address?: {
    street?: string;
    city?: string;
    state?: string;
    zipCode?: string;
    country?: string;
  };
  preferences?: {
    newsletter?: boolean;
    smsNotifications?: boolean;
    emailNotifications?: boolean;
  };
  createdAt?: Date;
  updatedAt?: Date;
  lastLoginAt?: Date;
  isActive?: boolean;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface SignupRequest {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  password: string;
  confirmPassword?: string;
  dateOfBirth?: string;
  address?: {
    street?: string;
    city?: string;
    state?: string;
    zipCode?: string;
    country?: string;
  };
}

export interface AuthResponse {
  token: string;
  user: User;
  expiresIn: number;
}

export interface PasswordResetRequest {
  email: string;
}

export interface PasswordResetConfirm {
  token: string;
  newPassword: string;
  confirmPassword: string;
}

export interface UserProfileUpdate {
  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
  dateOfBirth?: string;
  address?: {
    street?: string;
    city?: string;
    state?: string;
    zipCode?: string;
    country?: string;
  };
  preferences?: {
    newsletter?: boolean;
    smsNotifications?: boolean;
    emailNotifications?: boolean;
  };
}

export interface UserFilters {
  role?: 'CUSTOMER' | 'STAFF' | 'ADMIN';
  isActive?: boolean;
  city?: string;
  loyaltyPointsMin?: number;
  loyaltyPointsMax?: number;
  createdAtFrom?: Date;
  createdAtTo?: Date;
}
