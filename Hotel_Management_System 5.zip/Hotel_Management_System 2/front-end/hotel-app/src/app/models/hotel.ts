export interface Hotel {
  hotelId?: number;
  id?: number; // Alias for hotelId for backward compatibility
  name: string;
  city: string;
  address?: string;
  status: 'OPEN' | 'CLOSED' | 'UNDER_MAINTENANCE' | 'ACTIVE';
  rating?: number;
  totalRooms?: number;
  availableRooms?: number;
  description?: string;
  amenities?: string[];
  images?: string[];
  phone?: string;
  email?: string;
  website?: string;
  checkInTime?: string;
  checkOutTime?: string;
  createdAt?: Date;
  updatedAt?: Date;
  
  // Additional properties for backward compatibility
  [key: string]: any;
}

export interface HotelSearchFilters {
  city?: string;
  status?: 'OPEN' | 'CLOSED' | 'UNDER_MAINTENANCE';
  minRating?: number;
  amenities?: string[];
  checkInDate?: Date;
  checkOutDate?: Date;
  guests?: number;
}

export interface HotelSearchResult {
  hotels: Hotel[];
  totalCount: number;
  currentPage: number;
  totalPages: number;
}