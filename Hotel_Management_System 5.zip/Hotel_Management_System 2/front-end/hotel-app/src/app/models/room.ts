export interface Room {
  roomId?: number;
  id?: number; // Alias for roomId for backward compatibility
  hotelId?: number;
  roomTypeId?: number;
  roomNumber: string;
  status: 'AVAILABLE' | 'RESERVED' | 'OCCUPIED' | 'UNDER_MAINTENANCE';
  floorNumber: number;
  lastMaintenanceDate?: string;
  roomType?: RoomType; // Related room type for display
  createdAt?: Date;
  updatedAt?: Date;
  
  // Additional properties for backward compatibility
  [key: string]: any;
}

export interface RoomType {
  roomTypeId?: number;
  id?: number; // Alias for roomTypeId for backward compatibility
  hotelId?: number;
  category: 'STANDARD' | 'DELUXE' | 'SUITE' | string; // Allow string for flexibility
  name?: string; // Alias for category
  type?: string; // Alias for category
  capacity: number;
  maxGuests?: number; // Alias for capacity
  pricePerDay: number;
  basePrice?: number; // Alias for pricePerDay
  description?: string;
  amenities?: string[];
  images?: string[];
  size?: string;
  bedType?: string;
  createdAt?: Date;
  updatedAt?: Date;
  
  // Additional properties for backward compatibility
  [key: string]: any;
}

export interface RoomAvailability {
  roomId: number;
  roomNumber: string;
  roomType: RoomType;
  status: 'AVAILABLE' | 'RESERVED' | 'OCCUPIED' | 'UNDER_MAINTENANCE';
  pricePerDay: number;
  floorNumber: number;
}

export interface RoomSearchFilters {
  hotelId?: number;
  checkInDate?: Date;
  checkOutDate?: Date;
  guests?: number;
  roomTypeId?: number;
  status?: 'AVAILABLE' | 'RESERVED' | 'OCCUPIED' | 'UNDER_MAINTENANCE';
  minPrice?: number;
  maxPrice?: number;
  amenities?: string[];
}