import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { RoomService } from '../../../core/services/room.service';
import { HotelService } from '../../../core/services/hotel.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Room } from '../../../models/room';
import { Hotel } from '../../../models/hotel';

@Component({
  selector: 'app-edit-room',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './edit-room.component.html',
  styleUrls: ['./edit-room.component.css']
})
export class EditRoomComponent implements OnInit {
  roomForm: FormGroup;
  room: Room | null = null;
  hotels: Hotel[] = [];
  isSubmitting = false;
  isLoading = true;

  constructor(
    private fb: FormBuilder,
    public router: Router,
    private route: ActivatedRoute,
    private roomService: RoomService,
    private hotelService: HotelService,
    private notificationService: NotificationService
  ) {
    this.roomForm = this.fb.group({
      hotelId: ['', Validators.required],
      roomNumber: ['', Validators.required],
      floorNumber: [1, [Validators.required, Validators.min(1)]],
      status: ['AVAILABLE', Validators.required],
      lastMaintenanceDate: ['']
    });
  }

  ngOnInit() {
    this.loadHotels();
    this.loadRoomDetails();
  }

  loadHotels() {
    this.hotelService.getAllHotels().subscribe({
      next: (hotels) => {
        this.hotels = hotels.filter(hotel => hotel.status === 'OPEN');
      },
      error: (error: any) => {
        this.notificationService.error('Error', 'Failed to load hotels');
        console.error('Error loading hotels:', error);
      }
    });
  }

  loadRoomDetails() {
    const roomId = this.route.snapshot.paramMap.get('id');
    if (roomId) {
      this.roomService.getRoomById(+roomId).subscribe({
        next: (room) => {
          this.room = room;
          this.roomForm.patchValue({
            hotelId: room.hotelId,
            roomNumber: room.roomNumber,
            floorNumber: room.floorNumber,
            status: room.status,
            lastMaintenanceDate: room.lastMaintenanceDate || ''
          });
          this.isLoading = false;
        },
        error: (error: any) => {
          this.isLoading = false;
          this.notificationService.error('Error', 'Failed to load room details');
          console.error('Error loading room:', error);
        }
      });
    }
  }

  onSubmit() {
    if (this.roomForm.valid && this.room) {
      this.isSubmitting = true;
      const formValue = this.roomForm.value;
      
      const roomData: Partial<Room> = {
        hotelId: formValue.hotelId,
        roomNumber: formValue.roomNumber,
        floorNumber: formValue.floorNumber,
        status: formValue.status,
        lastMaintenanceDate: formValue.lastMaintenanceDate || undefined
      };

      this.roomService.updateRoom(this.room.roomId || this.room.id!, roomData).subscribe({
        next: (room) => {
          this.isSubmitting = false;
          this.notificationService.success('Success', 'Room updated successfully!');
          this.router.navigate(['/admin/rooms']);
        },
        error: (error: any) => {
          this.isSubmitting = false;
          this.notificationService.error('Error', 'Failed to update room');
          console.error('Error updating room:', error);
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  private markFormGroupTouched() {
    Object.keys(this.roomForm.controls).forEach(key => {
      const control = this.roomForm.get(key);
      control?.markAsTouched();
    });
  }

  get f() {
    return this.roomForm.controls;
  }
}
