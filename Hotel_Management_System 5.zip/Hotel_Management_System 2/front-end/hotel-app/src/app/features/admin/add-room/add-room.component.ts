import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { RoomService } from '../../../core/services/room.service';
import { HotelService } from '../../../core/services/hotel.service';
import { NotificationService } from '../../../core/services/notification.service';
import { Room } from '../../../models/room';
import { Hotel } from '../../../models/hotel';

@Component({
  selector: 'app-add-room',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './add-room.component.html',
  styleUrls: ['./add-room.component.css']
})
export class AddRoomComponent implements OnInit {
  roomForm: FormGroup;
  hotels: Hotel[] = [];
  isSubmitting = false;

  constructor(
    private fb: FormBuilder,
    public router: Router,
    private route: ActivatedRoute,
    private roomService: RoomService,
    private hotelService: HotelService,
    private notificationService: NotificationService
  ) {
    this.roomForm = this.fb.group({
      hotelId: ['', Validators.required],
      roomNumber: ['', Validators.required],
      floorNumber: [1, [Validators.required, Validators.min(1)]],
      status: ['AVAILABLE', Validators.required],
      lastMaintenanceDate: ['']
    });
  }

  ngOnInit() {
    this.loadHotels();
    
    // Pre-fill hotel if coming from hotel detail page
    const hotelId = this.route.snapshot.queryParams['hotelId'];
    if (hotelId) {
      this.roomForm.patchValue({ hotelId: +hotelId });
    }
  }

  loadHotels() {
    this.hotelService.getAllHotels().subscribe({
      next: (hotels) => {
        this.hotels = hotels.filter(hotel => hotel.status === 'OPEN');
      },
      error: (error: any) => {
        this.notificationService.error('Error', 'Failed to load hotels');
        console.error('Error loading hotels:', error);
      }
    });
  }

  onSubmit() {
    if (this.roomForm.valid) {
      this.isSubmitting = true;
      const formValue = this.roomForm.value;
      
      const roomData: Partial<Room> = {
        hotelId: formValue.hotelId,
        roomNumber: formValue.roomNumber,
        floorNumber: formValue.floorNumber,
        status: formValue.status,
        lastMaintenanceDate: formValue.lastMaintenanceDate || undefined
      };

      this.roomService.createRoom(roomData).subscribe({
        next: (room) => {
          this.isSubmitting = false;
          this.notificationService.success('Success', 'Room created successfully!');
          this.router.navigate(['/admin/rooms']);
        },
        error: (error: any) => {
          this.isSubmitting = false;
          this.notificationService.error('Error', 'Failed to create room');
          console.error('Error creating room:', error);
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  private markFormGroupTouched() {
    Object.keys(this.roomForm.controls).forEach(key => {
      const control = this.roomForm.get(key);
      control?.markAsTouched();
    });
  }

  get f() {
    return this.roomForm.controls;
  }
}
