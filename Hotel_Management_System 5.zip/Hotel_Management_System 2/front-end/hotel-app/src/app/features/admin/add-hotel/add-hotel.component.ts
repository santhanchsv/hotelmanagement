import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HotelService } from '../../../core/services/hotel.service';
import { Hotel } from '../../../models/hotel';
import { NotificationService } from '../../../core/services/notification.service';

@Component({
  selector: 'app-add-hotel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-hotel.component.html',
  styleUrls: ['./add-hotel.component.css']
})
export class AddHotelComponent {
  private hotelService = inject(HotelService);
  private router = inject(Router);
  private notificationService = inject(NotificationService);
  
  formError = '';
  isLoading = false;
 
  hotel: Partial<Hotel> = { 
    status: 'ACTIVE',
    name: '',
    city: '',
    address: '',
    description: '',
    amenities: [],
    images: []
  };
 
  save() {
    if (!this.hotel.name || !this.hotel.city) {
      this.formError = 'Name and City are required';
      return;
    }

    this.isLoading = true;
    this.formError = '';

    this.hotelService.createHotel(this.hotel).subscribe({
      next: () => {
        this.notificationService.success('Success', 'Hotel created successfully');
        this.router.navigate(['/admin/hotels']);
      },
      error: (err: any) => {
        this.isLoading = false;
        this.formError = 'Could not save hotel. Please try again';
        this.notificationService.error('Error', 'Failed to create hotel');
        console.error('Error creating hotel:', err);
      }
    });
  }
 
  cancel() {
    this.router.navigate(['/admin/hotels']);
  }
}
