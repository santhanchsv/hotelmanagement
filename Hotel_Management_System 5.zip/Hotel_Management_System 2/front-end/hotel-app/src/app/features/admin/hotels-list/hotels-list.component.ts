import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { HotelService } from '../../../core/services/hotel.service';
import { Hotel } from '../../../models/hotel';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-hotels-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './hotels-list.component.html',
  styleUrl: './hotels-list.component.css'
})
export class HotelsListComponent implements OnInit {
  private hotelService = inject(HotelService);
  private router = inject(Router);
  
  hotels: Hotel[] = [];
  filteredHotels: Hotel[] = [];
  loading = true;
  error = '';
  searchQuery = '';
  statusFilter = '';

  ngOnInit() {
    this.loadHotels();
  }

  loadHotels() {
    this.hotelService.getAllHotels().subscribe({
      next: (data) => {
        this.hotels = data;
        this.filteredHotels = data;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load hotels';
        this.loading = false;
        console.error(err);
      }
    });
  }

  onSearch() {
    this.filterHotels();
  }

  onStatusFilter() {
    this.filterHotels();
  }

  filterHotels() {
    this.filteredHotels = this.hotels.filter(hotel => {
      const matchesSearch = !this.searchQuery || 
        hotel.name.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
        hotel.city.toLowerCase().includes(this.searchQuery.toLowerCase());
      
      const matchesStatus = !this.statusFilter || hotel.status === this.statusFilter;
      
      return matchesSearch && matchesStatus;
    });
  }

  delete(id: number | any) {
    if (confirm("Are you sure you want to delete this hotel?")) {
      this.hotelService.deleteHotel(id).subscribe({
        next: () => {
          this.hotels = this.hotels.filter(h => h.hotelId !== id);
          this.filteredHotels = this.filteredHotels.filter(h => h.hotelId !== id);
        },
        error: (err) => alert('Error deleting hotel: ' + err.message)
      });
    }
  }

  getStatusBadgeClass(status: string): string {
    switch (status) {
      case 'OPEN': return 'badge bg-success';
      case 'CLOSED': return 'badge bg-danger';
      case 'UNDER_MAINTENANCE': return 'badge bg-warning';
      default: return 'badge bg-secondary';
    }
  }

  getStatusText(status: string): string {
    switch (status) {
      case 'OPEN': return 'Open';
      case 'CLOSED': return 'Closed';
      case 'UNDER_MAINTENANCE': return 'Under Maintenance';
      default: return status;
    }
  }
}