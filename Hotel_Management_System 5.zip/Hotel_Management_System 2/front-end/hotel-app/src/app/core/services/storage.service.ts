import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  // Local Storage methods
  setItem(key: string, value: any): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Error saving to localStorage', error);
    }
  }

  getItem<T>(key: string): T | null {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error('Error reading from localStorage', error);
      return null;
    }
  }

  removeItem(key: string): void {
    localStorage.removeItem(key);
  }

  clear(): void {
    localStorage.clear();
  }

  // Session Storage methods
  setSessionItem(key: string, value: any): void {
    try {
      sessionStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Error saving to sessionStorage', error);
    }
  }

  getSessionItem<T>(key: string): T | null {
    try {
      const item = sessionStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error('Error reading from sessionStorage', error);
      return null;
    }
  }

  removeSessionItem(key: string): void {
    sessionStorage.removeItem(key);
  }

  clearSession(): void {
    sessionStorage.clear();
  }

  // Utility methods
  hasItem(key: string): boolean {
    return localStorage.getItem(key) !== null;
  }

  hasSessionItem(key: string): boolean {
    return sessionStorage.getItem(key) !== null;
  }

  // Auth-specific methods
  setAuthData(token: string, user: any, expiresIn: number): void {
    const expiryTime = new Date(Date.now() + expiresIn * 1000);
    this.setItem('authToken', token);
    this.setItem('currentUser', user);
    this.setItem('tokenExpiry', expiryTime.toISOString());
  }

  getAuthData(): { token: string | null; user: any | null; isValid: boolean } {
    const token = this.getItem<string>('authToken');
    const user = this.getItem<any>('currentUser');
    const tokenExpiry = this.getItem<string>('tokenExpiry');
    
    let isValid = false;
    if (token && tokenExpiry) {
      const expiryTime = new Date(tokenExpiry).getTime();
      const currentTime = new Date().getTime();
      isValid = expiryTime > currentTime;
    }

    return { token, user, isValid };
  }

  clearAuthData(): void {
    this.removeItem('authToken');
    this.removeItem('currentUser');
    this.removeItem('tokenExpiry');
  }

  // Search and filter preferences
  setSearchPreferences(preferences: any): void {
    this.setItem('searchPreferences', preferences);
  }

  getSearchPreferences(): any {
    return this.getItem('searchPreferences') || {};
  }

  // User preferences
  setUserPreferences(preferences: any): void {
    this.setItem('userPreferences', preferences);
  }

  getUserPreferences(): any {
    return this.getItem('userPreferences') || {};
  }
}
