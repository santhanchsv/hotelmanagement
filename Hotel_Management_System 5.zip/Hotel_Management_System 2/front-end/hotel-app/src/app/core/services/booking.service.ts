import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Booking, BookingRequest, BookingSummary, BookingFilters } from '../../models/booking';
import { ApiService } from './api.service';
import { SearchParams } from '../../models/common';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private apiService = inject(ApiService);

  // Customer booking operations
  getMyBookings(userId: number, searchParams?: SearchParams): Observable<BookingSummary[]> {
    // Mock implementation for testing
    const mockBookings: BookingSummary[] = [
      {
        bookingId: 1,
        hotelName: 'Grand Plaza Hotel',
        roomNumber: '101',
        checkInDate: '2024-01-15',
        checkOutDate: '2024-01-17',
        totalAmount: 400,
        status: 'CONFIRMED',
        paymentStatus: 'PAID',
        numberOfNights: 2
      },
      {
        bookingId: 2,
        hotelName: 'Ocean View Resort',
        roomNumber: '201',
        checkInDate: '2024-02-20',
        checkOutDate: '2024-02-22',
        totalAmount: 600,
        status: 'PENDING',
        paymentStatus: 'UNPAID',
        numberOfNights: 2
      }
    ];

    // Get user's bookings from localStorage
    const userBookings = JSON.parse(localStorage.getItem('mockBookings') || '[]');
    const allBookings = [...mockBookings, ...userBookings];

    return new Observable(observer => {
      setTimeout(() => {
        observer.next(allBookings);
        observer.complete();
      }, 500);
    });
  }

  getMyBookingById(userId: number, bookingId: number): Observable<Booking> {
    return this.apiService.get<Booking>(`/api/booking/customer/${userId}/bookings/${bookingId}`);
  }

  createBooking(booking: BookingRequest): Observable<Booking> {
    // Mock implementation for testing
    const mockBooking: Booking = {
      bookingId: Math.floor(Math.random() * 1000),
      userId: booking.userId || 1,
      hotelId: booking.hotelId || 1,
      roomId: booking.roomId || 1,
      checkInDate: booking.checkInDate,
      checkOutDate: booking.checkOutDate,
      numberOfGuests: booking.numberOfGuests || 2,
      totalAmount: 200, // Calculate based on room type and nights
      status: 'PENDING',
      paymentStatus: 'UNPAID',
      specialRequests: booking.specialRequests || '',
      createdAt: new Date(),
      updatedAt: new Date(),
      room: {
        roomNumber: '101',
        roomType: {
          category: 'DELUXE',
          capacity: 2
        }
      }
    };

    // Store in localStorage for persistence
    const existingBookings = JSON.parse(localStorage.getItem('mockBookings') || '[]');
    existingBookings.push(mockBooking);
    localStorage.setItem('mockBookings', JSON.stringify(existingBookings));

    return new Observable(observer => {
      setTimeout(() => {
        observer.next(mockBooking);
        observer.complete();
      }, 1000);
    });
  }

  cancelMyBooking(userId: number, bookingId: number, reason?: string): Observable<Booking> {
    return this.apiService.patch<Booking>(`/api/booking/customer/${userId}/bookings/${bookingId}/cancel`, { reason });
  }

  modifyBooking(userId: number, bookingId: number, updates: Partial<BookingRequest>): Observable<Booking> {
    return this.apiService.patch<Booking>(`/api/booking/customer/${userId}/bookings/${bookingId}`, updates);
  }

  // Admin booking management
  getAllBookings(searchParams?: SearchParams): Observable<Booking[]> {
    return this.apiService.get<Booking[]>('/api/booking/admin/bookings', searchParams);
  }

  getBookingById(bookingId: number): Observable<Booking> {
    return this.apiService.get<Booking>(`/api/booking/admin/bookings/${bookingId}`);
  }

  getBookingsByHotel(hotelId: number, searchParams?: SearchParams): Observable<Booking[]> {
    return this.apiService.get<Booking[]>(`/api/booking/admin/hotels/${hotelId}/bookings`, searchParams);
  }

  getBookingsByRoom(hotelId: number, roomId: number, searchParams?: SearchParams): Observable<Booking[]> {
    return this.apiService.get<Booking[]>(`/api/booking/admin/hotels/${hotelId}/rooms/${roomId}/bookings`, searchParams);
  }

  getBookingsByUser(userId: number): Observable<Booking[]> {
    return this.apiService.get<Booking[]>(`/api/booking/user/${userId}/bookings`);
  }

  updateBooking(bookingId: number, booking: Partial<Booking>): Observable<Booking> {
    return this.apiService.put<Booking>(`/api/booking/admin/bookings/${bookingId}`, booking);
  }

  updateBookingStatus(bookingId: number, status: 'PENDING' | 'CONFIRMED' | 'CHECKED_IN' | 'CHECKED_OUT' | 'CANCELLED'): Observable<Booking> {
    return this.apiService.patch<Booking>(`/api/booking/admin/bookings/${bookingId}/status`, { status });
  }

  updatePaymentStatus(bookingId: number, paymentStatus: 'PAID' | 'UNPAID' | 'REFUNDED'): Observable<Booking> {
    return this.apiService.patch<Booking>(`/api/booking/admin/bookings/${bookingId}/payment`, { paymentStatus });
  }

  cancelBooking(bookingId: number, reason?: string): Observable<Booking> {
    return this.apiService.patch<Booking>(`/api/booking/admin/bookings/${bookingId}/cancel`, { reason });
  }

  checkIn(bookingId: number, checkInTime?: string): Observable<Booking> {
    return this.apiService.patch<Booking>(`/api/booking/admin/bookings/${bookingId}/checkin`, { checkInTime });
  }

  checkOut(bookingId: number, checkOutTime?: string): Observable<Booking> {
    return this.apiService.patch<Booking>(`/api/booking/admin/bookings/${bookingId}/checkout`, { checkOutTime });
  }

  // Booking search and filtering
  searchBookings(filters: BookingFilters, searchParams?: SearchParams): Observable<Booking[]> {
    const params = { ...filters, ...searchParams };
    return this.apiService.get<Booking[]>('/api/booking/admin/bookings/search', params);
  }

  getBookingsByStatus(status: 'PENDING' | 'CONFIRMED' | 'CHECKED_IN' | 'CHECKED_OUT' | 'CANCELLED', searchParams?: SearchParams): Observable<Booking[]> {
    return this.apiService.get<Booking[]>(`/api/booking/admin/bookings/status/${status}`, searchParams);
  }

  getBookingsByDateRange(startDate: string, endDate: string, searchParams?: SearchParams): Observable<Booking[]> {
    return this.apiService.get<Booking[]>(`/api/booking/admin/bookings/date-range`, {
      startDate,
      endDate,
      ...searchParams
    });
  }

  getBookingsByPaymentStatus(paymentStatus: 'PAID' | 'UNPAID' | 'REFUNDED', searchParams?: SearchParams): Observable<Booking[]> {
    return this.apiService.get<Booking[]>(`/api/booking/admin/bookings/payment-status/${paymentStatus}`, searchParams);
  }

  // Booking analytics and reports
  getBookingStatistics(hotelId?: number, startDate?: string, endDate?: string): Observable<any> {
    return this.apiService.get<any>('/api/booking/admin/statistics', {
      hotelId,
      startDate,
      endDate
    });
  }

  getRevenueReport(hotelId?: number, startDate?: string, endDate?: string): Observable<any> {
    return this.apiService.get<any>('/api/booking/admin/revenue-report', {
      hotelId,
      startDate,
      endDate
    });
  }

  getOccupancyReport(hotelId: number, startDate: string, endDate: string): Observable<any> {
    return this.apiService.get<any>('/api/booking/admin/occupancy-report', {
      hotelId,
      startDate,
      endDate
    });
  }

  // Booking confirmation and notifications
  sendBookingConfirmation(bookingId: number): Observable<any> {
    return this.apiService.post<any>(`/api/booking/admin/bookings/${bookingId}/send-confirmation`, {});
  }

  sendBookingReminder(bookingId: number): Observable<any> {
    return this.apiService.post<any>(`/api/booking/admin/bookings/${bookingId}/send-reminder`, {});
  }

  // Bulk operations
  bulkUpdateBookingStatus(bookingIds: number[], status: 'PENDING' | 'CONFIRMED' | 'CHECKED_IN' | 'CHECKED_OUT' | 'CANCELLED'): Observable<Booking[]> {
    return this.apiService.post<Booking[]>('/api/booking/admin/bookings/bulk-status', {
      bookingIds,
      status
    });
  }

  bulkCancelBookings(bookingIds: number[], reason?: string): Observable<Booking[]> {
    return this.apiService.post<Booking[]>('/api/booking/admin/bookings/bulk-cancel', {
      bookingIds,
      reason
    });
  }
}
