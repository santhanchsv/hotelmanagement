import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Hotel, HotelSearchFilters, HotelSearchResult } from '../../models/hotel';
import { ApiService } from './api.service';
import { SearchParams } from '../../models/common';

@Injectable({
  providedIn: 'root'
})
export class HotelService {
  private apiService = inject(ApiService);

  // Public hotel browsing (for customers)
  getPublicHotels(searchParams?: SearchParams): Observable<Hotel[]> {
    // Use the same mock data as admin
    return this.getAllHotels(searchParams);
  }

  getPublicHotelById(id: number): Observable<Hotel> {
    return this.apiService.get<Hotel>(`/api/catalog/hotels/${id}`).pipe(
      map(response => response)
    );
  }

  searchHotels(filters: HotelSearchFilters, searchParams?: SearchParams): Observable<HotelSearchResult> {
    const params = { ...filters, ...searchParams };
    return this.apiService.get<HotelSearchResult>('/api/catalog/hotels/search', params).pipe(
      map(response => response)
    );
  }

  getFeaturedHotels(): Observable<Hotel[]> {
    // Return first 3 hotels as featured
    return this.getAllHotels().pipe(
      map(hotels => hotels.slice(0, 3))
    );
  }

  getHotelsByCity(city: string): Observable<Hotel[]> {
    return this.apiService.get<Hotel[]>(`/api/catalog/hotels/city/${city}`).pipe(
      map(response => response)
    );
  }

  // Admin hotel management
  getAllHotels(searchParams?: SearchParams): Observable<Hotel[]> {
    // Mock implementation for testing - remove when backend is ready
    const mockHotels: Hotel[] = [
      {
        hotelId: 1,
        name: 'Grand Plaza Hotel',
        city: 'New York',
        address: '123 Broadway, New York, NY 10001',
        description: 'Luxurious hotel in the heart of Manhattan with stunning city views.',
        rating: 5,
        status: 'ACTIVE',
        amenities: ['WiFi', 'Pool', 'Spa', 'Restaurant', 'Gym'],
        images: ['https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&h=600&fit=crop'],
        createdAt: new Date('2023-01-15'),
        updatedAt: new Date('2023-01-15')
      },
      {
        hotelId: 2,
        name: 'Ocean View Resort',
        city: 'Miami',
        address: '456 Ocean Drive, Miami, FL 33139',
        description: 'Beachfront resort with direct access to the ocean and tropical gardens.',
        rating: 4,
        status: 'ACTIVE',
        amenities: ['WiFi', 'Pool', 'Beach Access', 'Restaurant', 'Bar'],
        images: ['https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800&h=600&fit=crop'],
        createdAt: new Date('2023-02-20'),
        updatedAt: new Date('2023-02-20')
      },
      {
        hotelId: 3,
        name: 'Mountain Lodge',
        city: 'Denver',
        address: '789 Mountain View, Denver, CO 80202',
        description: 'Cozy lodge nestled in the Rocky Mountains with breathtaking views.',
        rating: 4,
        status: 'ACTIVE',
        amenities: ['WiFi', 'Fireplace', 'Restaurant', 'Hiking Trails', 'Ski Access'],
        images: ['https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop'],
        createdAt: new Date('2023-03-10'),
        updatedAt: new Date('2023-03-10')
      }
    ];

    // Get hotels from localStorage (user-created ones)
    const userCreatedHotels = JSON.parse(localStorage.getItem('mockHotels') || '[]');
    const allHotels = [...mockHotels, ...userCreatedHotels];

    return new Observable(observer => {
      setTimeout(() => {
        observer.next(allHotels);
        observer.complete();
      }, 500); // Simulate API delay
    });
  }

  getHotelById(id: number): Observable<Hotel> {
    return this.apiService.get<Hotel>(`/api/admin/hotels/${id}`).pipe(
      map(response => response)
    );
  }

  createHotel(hotel: Partial<Hotel>): Observable<Hotel> {
    // Mock implementation for testing - remove when backend is ready
    const mockHotel: Hotel = {
      hotelId: Math.floor(Math.random() * 1000),
      name: hotel.name || 'New Hotel',
      city: hotel.city || 'Unknown City',
      address: hotel.address || '',
      description: hotel.description || '',
      rating: hotel.rating || 3,
      status: hotel.status || 'ACTIVE',
      amenities: hotel.amenities || [],
      images: hotel.images || [],
      createdAt: new Date(),
      updatedAt: new Date()
    };

    // Store in localStorage for persistence during session
    const existingHotels = JSON.parse(localStorage.getItem('mockHotels') || '[]');
    existingHotels.push(mockHotel);
    localStorage.setItem('mockHotels', JSON.stringify(existingHotels));

    return new Observable(observer => {
      setTimeout(() => {
        observer.next(mockHotel);
        observer.complete();
      }, 1000); // Simulate API delay
    });
  }

  updateHotel(id: number, hotel: Partial<Hotel>): Observable<Hotel> {
    return this.apiService.put<Hotel>(`/api/admin/hotels/${id}`, hotel).pipe(
      map(response => response)
    );
  }

  patchHotel(id: number, updates: Partial<Hotel>): Observable<Hotel> {
    return this.apiService.patch<Hotel>(`/api/admin/hotels/${id}`, updates).pipe(
      map(response => response)
    );
  }

  deleteHotel(id: number): Observable<void> {
    return this.apiService.delete<void>(`/api/admin/hotels/${id}`).pipe(
      map(() => void 0)
    );
  }

  updateHotelStatus(id: number, status: 'OPEN' | 'CLOSED' | 'UNDER_MAINTENANCE'): Observable<Hotel> {
    return this.apiService.patch<Hotel>(`/api/admin/hotels/${id}/status`, { status }).pipe(
      map(response => response)
    );
  }

  uploadHotelImages(id: number, files: File[]): Observable<string[]> {
    const formData = new FormData();
    files.forEach(file => formData.append('files', file));
    
    return this.apiService.post<string[]>(`/api/admin/hotels/${id}/images`, formData).pipe(
      map(response => response)
    );
  }

  deleteHotelImage(id: number, imageUrl: string): Observable<void> {
    return this.apiService.delete<void>(`/api/admin/hotels/${id}/images?imageUrl=${encodeURIComponent(imageUrl)}`).pipe(
      map(() => void 0)
    );
  }

  getHotelStatistics(id: number): Observable<any> {
    return this.apiService.get<any>(`/api/admin/hotels/${id}/statistics`);
  }

  getHotelReviews(id: number, searchParams?: SearchParams): Observable<any> {
    return this.apiService.get<any>(`/api/catalog/hotels/${id}/reviews`, searchParams);
  }

  addHotelReview(hotelId: number, review: any): Observable<any> {
    return this.apiService.post<any>(`/api/catalog/hotels/${hotelId}/reviews`, review);
  }
}
