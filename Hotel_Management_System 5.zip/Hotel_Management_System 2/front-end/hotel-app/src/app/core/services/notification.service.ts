import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { NotificationMessage } from '../../models/common';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  private notificationsSubject = new BehaviorSubject<NotificationMessage[]>([]);
  public notifications$ = this.notificationsSubject.asObservable();

  private showNotification(message: NotificationMessage): void {
    const currentNotifications = this.notificationsSubject.value;
    const newNotification = {
      ...message,
      id: Date.now().toString()
    };
    
    this.notificationsSubject.next([...currentNotifications, newNotification]);

    // Auto-remove notification after duration
    if (message.duration && message.duration > 0) {
      setTimeout(() => {
        this.removeNotification(newNotification.id);
      }, message.duration);
    }
  }

  success(title: string, message: string, duration: number = 5000): void {
    this.showNotification({
      type: 'success',
      title,
      message,
      duration
    });
  }

  error(title: string, message: string, duration: number = 0): void {
    this.showNotification({
      type: 'error',
      title,
      message,
      duration
    });
  }

  warning(title: string, message: string, duration: number = 5000): void {
    this.showNotification({
      type: 'warning',
      title,
      message,
      duration
    });
  }

  info(title: string, message: string, duration: number = 5000): void {
    this.showNotification({
      type: 'info',
      title,
      message,
      duration
    });
  }

  removeNotification(id: string): void {
    const currentNotifications = this.notificationsSubject.value;
    const filteredNotifications = currentNotifications.filter(n => n.id !== id);
    this.notificationsSubject.next(filteredNotifications);
  }

  clearAll(): void {
    this.notificationsSubject.next([]);
  }

  getNotifications(): NotificationMessage[] {
    return this.notificationsSubject.value;
  }
}
