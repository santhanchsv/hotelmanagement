import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Room, RoomType, RoomAvailability, RoomSearchFilters } from '../../models/room';
import { ApiService } from './api.service';
import { SearchParams } from '../../models/common';

@Injectable({
  providedIn: 'root'
})
export class RoomService {
  private apiService = inject(ApiService);

  // Public room browsing (for customers)
  getAvailableRooms(hotelId: number, filters: RoomSearchFilters): Observable<RoomAvailability[]> {
    return this.apiService.get<RoomAvailability[]>(`/api/catalog/hotels/${hotelId}/rooms/available`, filters);
  }

  getRoomTypes(hotelId: number): Observable<RoomType[]> {
    return this.apiService.get<RoomType[]>(`/api/catalog/hotels/${hotelId}/roomtypes`);
  }

  getRoomTypeById(hotelId: number, roomTypeId: number): Observable<RoomType> {
    return this.apiService.get<RoomType>(`/api/catalog/hotels/${hotelId}/roomtypes/${roomTypeId}`);
  }

  checkRoomAvailability(hotelId: number, roomTypeId: number, checkInDate: string, checkOutDate: string): Observable<boolean> {
    return this.apiService.get<boolean>(`/api/catalog/hotels/${hotelId}/rooms/availability`, {
      roomTypeId,
      checkInDate,
      checkOutDate
    });
  }

  // Admin room type management
  getAdminRoomTypes(hotelId: number, searchParams?: SearchParams): Observable<RoomType[]> {
    return this.apiService.get<RoomType[]>(`/api/admin/hotels/${hotelId}/roomtypes`, searchParams);
  }

  getAdminRoomTypeById(hotelId: number, roomTypeId: number): Observable<RoomType> {
    return this.apiService.get<RoomType>(`/api/admin/hotels/${hotelId}/roomtypes/${roomTypeId}`);
  }

  createRoomType(hotelId: number, roomType: Partial<RoomType>): Observable<RoomType> {
    return this.apiService.post<RoomType>(`/api/admin/hotels/${hotelId}/roomtypes`, roomType);
  }

  updateRoomType(hotelId: number, roomTypeId: number, roomType: Partial<RoomType>): Observable<RoomType> {
    return this.apiService.put<RoomType>(`/api/admin/hotels/${hotelId}/roomtypes/${roomTypeId}`, roomType);
  }

  patchRoomType(hotelId: number, roomTypeId: number, updates: Partial<RoomType>): Observable<RoomType> {
    return this.apiService.patch<RoomType>(`/api/admin/hotels/${hotelId}/roomtypes/${roomTypeId}`, updates);
  }

  deleteRoomType(hotelId: number, roomTypeId: number): Observable<void> {
    return this.apiService.delete<void>(`/api/admin/hotels/${hotelId}/roomtypes/${roomTypeId}`);
  }

  uploadRoomTypeImages(hotelId: number, roomTypeId: number, files: File[]): Observable<string[]> {
    const formData = new FormData();
    files.forEach(file => formData.append('files', file));
    
    return this.apiService.post<string[]>(`/api/admin/hotels/${hotelId}/roomtypes/${roomTypeId}/images`, formData);
  }

  // Admin room management
  getAdminRooms(hotelId: number, searchParams?: SearchParams): Observable<Room[]> {
    return this.apiService.get<Room[]>(`/api/admin/hotels/${hotelId}/rooms`, searchParams);
  }

  getAdminRoomById(hotelId: number, roomId: number): Observable<Room> {
    return this.apiService.get<Room>(`/api/admin/hotels/${hotelId}/rooms/${roomId}`);
  }

  createRoomForHotel(hotelId: number, room: Partial<Room>): Observable<Room> {
    return this.apiService.post<Room>(`/api/admin/hotels/${hotelId}/rooms`, room).pipe(
      map(response => response)
    );
  }

  updateRoomForHotel(hotelId: number, roomId: number, room: Partial<Room>): Observable<Room> {
    return this.apiService.put<Room>(`/api/admin/hotels/${hotelId}/rooms/${roomId}`, room).pipe(
      map(response => response)
    );
  }

  patchRoom(hotelId: number, roomId: number, updates: Partial<Room>): Observable<Room> {
    return this.apiService.patch<Room>(`/api/admin/hotels/${hotelId}/rooms/${roomId}`, updates).pipe(
      map(response => response)
    );
  }

  deleteRoomForHotel(hotelId: number, roomId: number): Observable<void> {
    return this.apiService.delete<void>(`/api/admin/hotels/${hotelId}/rooms/${roomId}`).pipe(
      map(() => void 0)
    );
  }

  updateRoomStatus(hotelId: number, roomId: number, status: 'AVAILABLE' | 'RESERVED' | 'OCCUPIED' | 'UNDER_MAINTENANCE'): Observable<Room> {
    return this.apiService.patch<Room>(`/api/admin/hotels/${hotelId}/rooms/${roomId}/status`, { status });
  }

  scheduleMaintenance(hotelId: number, roomId: number, maintenanceDate: string, notes?: string): Observable<Room> {
    return this.apiService.post<Room>(`/api/admin/hotels/${hotelId}/rooms/${roomId}/maintenance`, {
      maintenanceDate,
      notes
    });
  }

  getRoomMaintenanceHistory(hotelId: number, roomId: number): Observable<any[]> {
    return this.apiService.get<any[]>(`/api/admin/hotels/${hotelId}/rooms/${roomId}/maintenance-history`);
  }

  getRoomOccupancyStats(hotelId: number, roomId: number, startDate: string, endDate: string): Observable<any> {
    return this.apiService.get<any>(`/api/admin/hotels/${hotelId}/rooms/${roomId}/occupancy-stats`, {
      startDate,
      endDate
    });
  }

  bulkUpdateRoomStatus(hotelId: number, roomIds: number[], status: 'AVAILABLE' | 'RESERVED' | 'OCCUPIED' | 'UNDER_MAINTENANCE'): Observable<Room[]> {
    return this.apiService.post<Room[]>(`/api/admin/hotels/${hotelId}/rooms/bulk-status`, {
      roomIds,
      status
    });
  }

  // Additional methods for general room management
  getAllRooms(): Observable<Room[]> {
    // Mock implementation for testing
    const mockRooms: Room[] = [
      {
        roomId: 1,
        hotelId: 1,
        roomNumber: '101',
        floorNumber: 1,
        status: 'AVAILABLE',
        roomType: {
          roomTypeId: 1,
          category: 'DELUXE',
          capacity: 2,
          pricePerDay: 200,
          amenities: ['WiFi', 'TV', 'Mini Bar', 'Balcony'],
          description: 'Spacious deluxe room with city view'
        },
        lastMaintenanceDate: '2023-12-01',
        createdAt: new Date('2023-01-15'),
        updatedAt: new Date('2023-12-01')
      },
      {
        roomId: 2,
        hotelId: 1,
        roomNumber: '102',
        floorNumber: 1,
        status: 'AVAILABLE',
        roomType: {
          roomTypeId: 2,
          category: 'STANDARD',
          capacity: 1,
          pricePerDay: 100,
          amenities: ['WiFi', 'TV'],
          description: 'Comfortable standard room'
        },
        lastMaintenanceDate: '2023-11-15',
        createdAt: new Date('2023-01-15'),
        updatedAt: new Date('2023-11-15')
      },
      {
        roomId: 3,
        hotelId: 2,
        roomNumber: '201',
        floorNumber: 2,
        status: 'OCCUPIED',
        roomType: {
          roomTypeId: 3,
          category: 'SUITE',
          capacity: 4,
          pricePerDay: 300,
          amenities: ['WiFi', 'TV', 'Kitchen', 'Ocean View', 'Balcony'],
          description: 'Luxurious suite with ocean view'
        },
        lastMaintenanceDate: '2023-10-20',
        createdAt: new Date('2023-02-20'),
        updatedAt: new Date('2023-10-20')
      }
    ];

    return new Observable(observer => {
      setTimeout(() => {
        observer.next(mockRooms);
        observer.complete();
      }, 500);
    });
  }

  getRoomsByHotel(hotelId: number): Observable<Room[]> {
    // Return rooms for specific hotel
    return this.getAllRooms().pipe(
      map(rooms => rooms.filter(room => room.hotelId === hotelId))
    );
  }

  getRoomById(roomId: number): Observable<Room> {
    return this.apiService.get<Room>(`/api/catalog/rooms/${roomId}`);
  }

  createRoom(room: Partial<Room>): Observable<Room> {
    return this.apiService.post<Room>('/api/admin/rooms', room);
  }

  updateRoom(roomId: number, room: Partial<Room>): Observable<Room> {
    return this.apiService.put<Room>(`/api/admin/rooms/${roomId}`, room);
  }

  deleteRoom(roomId: number): Observable<void> {
    return this.apiService.delete<void>(`/api/admin/rooms/${roomId}`);
  }
}
