import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { LoadingState } from '../../models/common';

@Injectable({
  providedIn: 'root'
})
export class LoadingService {
  private loadingSubject = new BehaviorSubject<LoadingState>({ isLoading: false });
  public loading$ = this.loadingSubject.asObservable();

  private loadingCount = 0;

  show(message?: string): void {
    this.loadingCount++;
    this.loadingSubject.next({
      isLoading: true,
      message: message || 'Loading...'
    });
  }

  hide(): void {
    this.loadingCount = Math.max(0, this.loadingCount - 1);
    
    if (this.loadingCount === 0) {
      this.loadingSubject.next({ isLoading: false });
    }
  }

  forceHide(): void {
    this.loadingCount = 0;
    this.loadingSubject.next({ isLoading: false });
  }

  updateMessage(message: string): void {
    const currentState = this.loadingSubject.value;
    if (currentState.isLoading) {
      this.loadingSubject.next({
        isLoading: true,
        message
      });
    }
  }

  isLoading(): boolean {
    return this.loadingSubject.value.isLoading;
  }

  getCurrentMessage(): string | undefined {
    return this.loadingSubject.value.message;
  }
}
