import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, Observable, tap, catchError, throwError } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { User, LoginRequest, SignupRequest, AuthResponse, PasswordResetRequest, PasswordResetConfirm } from '../../models/user';
import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiService = inject(ApiService);
  private router = inject(Router);
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();
  private redirectUrl: string | null = null;

  constructor() {
    this.initializeAuth();
  }

  private initializeAuth(): void {
    const token = localStorage.getItem('authToken');
    const userData = localStorage.getItem('currentUser');
    const tokenExpiry = localStorage.getItem('tokenExpiry');
    
    if (token && userData && tokenExpiry) {
      const expiryTime = new Date(tokenExpiry).getTime();
      const currentTime = new Date().getTime();
      
      if (expiryTime > currentTime) {
        this.currentUserSubject.next(JSON.parse(userData));
      } else {
        this.logout();
      }
    }
  }

  login(credentials: LoginRequest): Observable<AuthResponse> {
    // Mock authentication for testing - remove when backend is ready
    const mockUsers = [
      { email: 'admin@hotel.com', password: 'admin123', role: 'ADMIN', name: 'Admin User' },
      { email: 'staff@hotel.com', password: 'staff123', role: 'STAFF', name: 'Staff User' },
      { email: 'customer@hotel.com', password: 'customer123', role: 'CUSTOMER', name: 'Customer User' },
      { email: 'test@hotel.com', password: 'test123', role: 'CUSTOMER', name: 'Test User' }
    ];

    const user = mockUsers.find(u => u.email === credentials.email && u.password === credentials.password);
    
    if (user) {
      const mockResponse: AuthResponse = {
        user: {
          userId: Math.floor(Math.random() * 1000),
          email: user.email,
          firstName: user.name.split(' ')[0],
          lastName: user.name.split(' ')[1] || '',
          role: user.role as 'CUSTOMER' | 'STAFF' | 'ADMIN',
          phoneNumber: '+1234567890',
          dateOfBirth: '1990-01-01',
          address: {
            street: '123 Main St',
            city: 'City',
            state: 'State',
            zipCode: '12345',
            country: 'USA'
          },
          isActive: true,
          createdAt: new Date(),
          updatedAt: new Date()
        },
        token: 'mock-jwt-token-' + Date.now(),
        expiresIn: 3600
      };

      this.setCurrentUser(mockResponse.user, mockResponse.token, mockResponse.expiresIn);
      return new Observable(observer => {
        observer.next(mockResponse);
        observer.complete();
      });
    } else {
      return throwError(() => new Error('Invalid credentials'));
    }
  }

  signup(userData: SignupRequest): Observable<AuthResponse> {
    // Mock signup for testing - remove when backend is ready
    const mockResponse: AuthResponse = {
      user: {
        userId: Math.floor(Math.random() * 1000),
        email: userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        role: 'CUSTOMER',
        phoneNumber: userData.phoneNumber || '+1234567890',
        dateOfBirth: userData.dateOfBirth || '1990-01-01',
        address: userData.address || {
          street: '123 Main St',
          city: 'City',
          state: 'State',
          zipCode: '12345',
          country: 'USA'
        },
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      token: 'mock-jwt-token-' + Date.now(),
      expiresIn: 3600
    };

    this.setCurrentUser(mockResponse.user, mockResponse.token, mockResponse.expiresIn);
    return new Observable(observer => {
      observer.next(mockResponse);
      observer.complete();
    });
  }

  logout(): void {
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');
    localStorage.removeItem('tokenExpiry');
    this.currentUserSubject.next(null);
    this.router.navigate(['/']);
  }

  setCurrentUser(user: User, token: string, expiresIn: number): void {
    const expiryTime = new Date(Date.now() + expiresIn * 1000);
    
    localStorage.setItem('authToken', token);
    localStorage.setItem('currentUser', JSON.stringify(user));
    localStorage.setItem('tokenExpiry', expiryTime.toISOString());
    
    this.currentUserSubject.next(user);
  }

  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  getToken(): string | null {
    return localStorage.getItem('authToken');
  }

  isAuthenticated(): boolean {
    const token = this.getToken();
    const tokenExpiry = localStorage.getItem('tokenExpiry');
    
    if (!token || !tokenExpiry) {
      return false;
    }
    
    const expiryTime = new Date(tokenExpiry).getTime();
    const currentTime = new Date().getTime();
    
    return expiryTime > currentTime;
  }

  isAdmin(): boolean {
    const user = this.getCurrentUser();
    return user?.role === 'ADMIN';
  }

  isStaff(): boolean {
    const user = this.getCurrentUser();
    return user?.role === 'STAFF';
  }

  isCustomer(): boolean {
    const user = this.getCurrentUser();
    return user?.role === 'CUSTOMER';
  }

  hasRole(role: 'CUSTOMER' | 'STAFF' | 'ADMIN'): boolean {
    const user = this.getCurrentUser();
    return user?.role === role;
  }

  hasAnyRole(roles: ('CUSTOMER' | 'STAFF' | 'ADMIN')[]): boolean {
    const user = this.getCurrentUser();
    return user ? roles.includes(user.role) : false;
  }

  requestPasswordReset(request: PasswordResetRequest): Observable<any> {
    return this.apiService.post('/api/user/auth/forgot-password', request);
  }

  confirmPasswordReset(confirm: PasswordResetConfirm): Observable<any> {
    return this.apiService.post('/api/user/auth/reset-password', confirm);
  }

  refreshToken(): Observable<AuthResponse> {
    return this.apiService.post<AuthResponse>('/api/user/auth/refresh', {}).pipe(
      map(response => response),
      tap(authResponse => {
        this.setCurrentUser(authResponse.user, authResponse.token, authResponse.expiresIn);
      })
    );
  }

  updateProfile(profileData: Partial<User>): Observable<User> {
    return this.apiService.put<User>('/api/user/profile', profileData).pipe(
      map(response => response),
      tap(user => {
        const currentToken = this.getToken();
        const currentExpiry = localStorage.getItem('tokenExpiry');
        if (currentToken && currentExpiry) {
          this.setCurrentUser(user, currentToken, new Date(currentExpiry).getTime() / 1000);
        }
      })
    );
  }

  changePassword(currentPassword: string, newPassword: string): Observable<any> {
    return this.apiService.post('/api/user/change-password', {
      currentPassword,
      newPassword
    });
  }

  setRedirectUrl(url: string): void {
    this.redirectUrl = url;
  }

  getRedirectUrl(): string | null {
    return this.redirectUrl;
  }

  clearRedirectUrl(): void {
    this.redirectUrl = null;
  }

  redirectAfterLogin(): void {
    const url = this.getRedirectUrl();
    this.clearRedirectUrl();
    this.router.navigate([url || '/']);
  }

  resetPassword(email: string): Observable<any> {
    return this.apiService.post<any>('/api/auth/reset-password', { email });
  }
}
