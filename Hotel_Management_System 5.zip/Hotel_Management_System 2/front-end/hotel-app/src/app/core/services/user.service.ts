import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { User, UserProfileUpdate, UserFilters } from '../../models/user';
import { ApiService } from './api.service';
import { SearchParams } from '../../models/common';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiService = inject(ApiService);

  // Customer profile operations
  getMyProfile(userId: number): Observable<User> {
    return this.apiService.get<User>(`/api/user/customer/${userId}/profile`);
  }

  updateMyProfile(userId: number, profileData: UserProfileUpdate): Observable<User> {
    return this.apiService.put<User>(`/api/user/customer/${userId}/profile`, profileData);
  }

  changePassword(userId: number, currentPassword: string, newPassword: string): Observable<any> {
    return this.apiService.post<any>(`/api/user/customer/${userId}/change-password`, {
      currentPassword,
      newPassword
    });
  }

  updatePreferences(userId: number, preferences: any): Observable<User> {
    return this.apiService.patch<User>(`/api/user/customer/${userId}/preferences`, preferences);
  }

  getMyLoyaltyPoints(userId: number): Observable<{ points: number; tier: string; nextTierPoints: number }> {
    return this.apiService.get<any>(`/api/user/customer/${userId}/loyalty-points`);
  }

  getMyBookingHistory(userId: number, searchParams?: SearchParams): Observable<any[]> {
    return this.apiService.get<any[]>(`/api/user/customer/${userId}/booking-history`, searchParams);
  }

  // Admin user management
  getAllUsers(searchParams?: SearchParams): Observable<User[]> {
    return this.apiService.get<User[]>('/api/user/admin/users', searchParams);
  }

  getUserById(userId: number): Observable<User> {
    return this.apiService.get<User>(`/api/user/admin/users/${userId}`);
  }

  getUserByEmail(email: string): Observable<User> {
    return this.apiService.get<User>(`/api/user/admin/users/email/${email}`);
  }

  createUser(user: Partial<User>): Observable<User> {
    return this.apiService.post<User>('/api/user/admin/users', user);
  }

  updateUser(userId: number, user: Partial<User>): Observable<User> {
    return this.apiService.put<User>(`/api/user/admin/users/${userId}`, user);
  }

  patchUser(userId: number, updates: Partial<User>): Observable<User> {
    return this.apiService.patch<User>(`/api/user/admin/users/${userId}`, updates);
  }

  deleteUser(userId: number): Observable<void> {
    return this.apiService.delete<void>(`/api/user/admin/users/${userId}`);
  }

  activateUser(userId: number): Observable<User> {
    return this.apiService.patch<User>(`/api/user/admin/users/${userId}/activate`, {});
  }

  deactivateUser(userId: number): Observable<User> {
    return this.apiService.patch<User>(`/api/user/admin/users/${userId}/deactivate`, {});
  }

  // User role management
  getUsersByRole(role: 'CUSTOMER' | 'STAFF' | 'ADMIN', searchParams?: SearchParams): Observable<User[]> {
    return this.apiService.get<User[]>(`/api/user/admin/users/role/${role}`, searchParams);
  }

  updateUserRole(userId: number, role: 'CUSTOMER' | 'STAFF' | 'ADMIN'): Observable<User> {
    return this.apiService.patch<User>(`/api/user/admin/users/${userId}/role`, { role });
  }

  // Loyalty points management
  updateLoyaltyPoints(userId: number, points: number, reason?: string): Observable<User> {
    return this.apiService.patch<User>(`/api/user/admin/users/${userId}/loyalty-points`, {
      points,
      reason
    });
  }

  addLoyaltyPoints(userId: number, points: number, reason?: string): Observable<User> {
    return this.apiService.post<User>(`/api/user/admin/users/${userId}/loyalty-points/add`, {
      points,
      reason
    });
  }

  deductLoyaltyPoints(userId: number, points: number, reason?: string): Observable<User> {
    return this.apiService.post<User>(`/api/user/admin/users/${userId}/loyalty-points/deduct`, {
      points,
      reason
    });
  }

  resetLoyaltyPoints(userId: number): Observable<User> {
    return this.apiService.patch<User>(`/api/user/admin/users/${userId}/loyalty-points/reset`, {});
  }

  // User search and filtering
  searchUsers(filters: UserFilters, searchParams?: SearchParams): Observable<User[]> {
    const params = { ...filters, ...searchParams };
    return this.apiService.get<User[]>(`/api/user/admin/users/search`, params);
  }

  getUsersByCity(city: string, searchParams?: SearchParams): Observable<User[]> {
    return this.apiService.get<User[]>(`/api/user/admin/users/city/${city}`, searchParams);
  }

  getUsersByLoyaltyTier(tier: string, searchParams?: SearchParams): Observable<User[]> {
    return this.apiService.get<User[]>(`/api/user/admin/users/loyalty-tier/${tier}`, searchParams);
  }

  // User analytics and reports
  getUserStatistics(): Observable<any> {
    return this.apiService.get<any>('/api/user/admin/statistics');
  }

  getUserRegistrationReport(startDate: string, endDate: string): Observable<any> {
    return this.apiService.get<any>('/api/user/admin/registration-report', {
      startDate,
      endDate
    });
  }

  getLoyaltyPointsReport(): Observable<any> {
    return this.apiService.get<any>('/api/user/admin/loyalty-points-report');
  }

  // User activity tracking
  updateLastLogin(userId: number): Observable<User> {
    return this.apiService.patch<User>(`/api/user/admin/users/${userId}/last-login`, {});
  }

  getUserActivityLog(userId: number, searchParams?: SearchParams): Observable<any[]> {
    return this.apiService.get<any[]>(`/api/user/admin/users/${userId}/activity-log`, searchParams);
  }

  // Bulk operations
  bulkUpdateUserStatus(userIds: number[], isActive: boolean): Observable<User[]> {
    return this.apiService.post<User[]>('/api/user/admin/users/bulk-status', {
      userIds,
      isActive
    });
  }

  bulkUpdateUserRole(userIds: number[], role: 'CUSTOMER' | 'STAFF' | 'ADMIN'): Observable<User[]> {
    return this.apiService.post<User[]>('/api/user/admin/users/bulk-role', {
      userIds,
      role
    });
  }

  bulkAddLoyaltyPoints(userIds: number[], points: number, reason?: string): Observable<User[]> {
    return this.apiService.post<User[]>('/api/user/admin/users/bulk-loyalty-points', {
      userIds,
      points,
      reason
    });
  }

  // User verification and security
  verifyUserEmail(userId: number): Observable<any> {
    return this.apiService.post<any>(`/api/user/admin/users/${userId}/verify-email`, {});
  }

  resetUserPassword(userId: number): Observable<any> {
    return this.apiService.post<any>(`/api/user/admin/users/${userId}/reset-password`, {});
  }

  lockUserAccount(userId: number, reason?: string): Observable<User> {
    return this.apiService.patch<User>(`/api/user/admin/users/${userId}/lock`, { reason });
  }

  unlockUserAccount(userId: number): Observable<User> {
    return this.apiService.patch<User>(`/api/user/admin/users/${userId}/unlock`, {});
  }
}
