import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {
  private notificationService = inject(NotificationService);
  
  currentYear = new Date().getFullYear();
  newsletterEmail = '';

  onNewsletterSubmit(): void {
    if (this.newsletterEmail.trim()) {
      // Here you would typically send the email to your backend
      this.notificationService.success(
        'Newsletter Subscription',
        'Thank you for subscribing to our newsletter!'
      );
      this.newsletterEmail = '';
    }
  }
}
