import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HotelService } from '../../../core/services/hotel.service';
import { RoomService } from '../../../core/services/room.service';
import { Hotel } from '../../../models/hotel';
import { Room, RoomType } from '../../../models/room';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';

@Component({
  selector: 'app-hotel-detail',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './hotel-detail.component.html',
  styleUrls: ['./hotel-detail.component.css']
})
export class HotelDetailComponent implements OnInit {
  hotel: Hotel | null = null;
  rooms: Room[] = [];
  roomTypes: RoomType[] = [];
  isLoading = true;
  isAdmin = false;
  selectedRoomType: string = 'all';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private hotelService: HotelService,
    private roomService: RoomService,
    private authService: AuthService,
    private notificationService: NotificationService
  ) {}

  ngOnInit() {
    this.isAdmin = this.authService.isAdmin();
    this.loadHotelDetails();
  }

  loadHotelDetails() {
    const hotelId = this.route.snapshot.paramMap.get('id');
    if (hotelId) {
      this.hotelService.getHotelById(+hotelId).subscribe({
        next: (hotel) => {
          this.hotel = hotel;
          this.loadRooms(+hotelId);
        },
        error: (error: any) => {
          this.isLoading = false;
          this.notificationService.error('Error', 'Failed to load hotel details');
          console.error('Error loading hotel:', error);
        }
      });
    }
  }

  loadRooms(hotelId: number) {
    this.roomService.getRoomsByHotel(hotelId).subscribe({
      next: (rooms: Room[]) => {
        this.rooms = rooms;
        this.extractRoomTypes();
        this.isLoading = false;
      },
      error: (error: any) => {
        this.isLoading = false;
        this.notificationService.error('Error', 'Failed to load rooms');
        console.error('Error loading rooms:', error);
      }
    });
  }

  extractRoomTypes() {
    const types = new Map<string, RoomType>();
    this.rooms.forEach(room => {
      if (room.roomType) {
        types.set(room.roomType.category, room.roomType);
      }
    });
    this.roomTypes = Array.from(types.values());
  }

  getFilteredRooms(): Room[] {
    if (this.selectedRoomType === 'all') {
      return this.rooms;
    }
    return this.rooms.filter(room => 
      room.roomType?.category === this.selectedRoomType
    );
  }

  getStatusBadgeClass(status: string): string {
    switch (status) {
      case 'AVAILABLE':
        return 'badge bg-success';
      case 'RESERVED':
        return 'badge bg-warning';
      case 'OCCUPIED':
        return 'badge bg-danger';
      case 'UNDER_MAINTENANCE':
        return 'badge bg-secondary';
      default:
        return 'badge bg-secondary';
    }
  }

  getStars(rating: number): number[] {
    return Array(Math.floor(rating)).fill(0);
  }

  getEmptyStars(rating: number): number[] {
    return Array(5 - Math.floor(rating)).fill(0);
  }

  deleteHotel() {
    if (this.hotel && confirm('Are you sure you want to delete this hotel?')) {
      this.hotelService.deleteHotel(this.hotel.hotelId || this.hotel.id!).subscribe({
        next: () => {
          this.notificationService.success('Success', 'Hotel deleted successfully');
          this.router.navigate(['/hotels']);
        },
        error: (error: any) => {
          this.notificationService.error('Error', 'Failed to delete hotel');
          console.error('Error deleting hotel:', error);
        }
      });
    }
  }

  bookRoom(room: Room) {
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/bookings/new'], { 
        queryParams: { 
          hotelId: this.hotel?.hotelId || this.hotel?.id,
          roomId: room.roomId || room.id
        }
      });
    } else {
      this.router.navigate(['/login'], { 
        queryParams: { returnUrl: this.router.url }
      });
    }
  }

  deleteRoom(roomId: number) {
    if (confirm('Are you sure you want to delete this room?') && this.hotel) {
      const hotelId = this.hotel.hotelId || this.hotel.id!;
      this.roomService.deleteRoomForHotel(hotelId, roomId).subscribe({
        next: () => {
          this.notificationService.success('Success', 'Room deleted successfully');
          this.loadRooms(hotelId);
        },
        error: (error: any) => {
          this.notificationService.error('Error', 'Failed to delete room');
          console.error('Error deleting room:', error);
        }
      });
    }
  }
}
