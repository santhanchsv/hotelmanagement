import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HotelService } from '../../../core/services/hotel.service';
import { Hotel, HotelSearchFilters } from '../../../models/hotel';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';

@Component({
  selector: 'app-hotels-list',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './hotels-list.component.html',
  styleUrls: ['./hotels-list.component.css']
})
export class HotelsListComponent implements OnInit {
  hotels: Hotel[] = [];
  filteredHotels: Hotel[] = [];
  isLoading = false;
  searchFilters: HotelSearchFilters = {};
  currentPage = 1;
  itemsPerPage = 9;
  totalPages = 0;
  isAdmin = false;

  constructor(
    private hotelService: HotelService,
    private authService: AuthService,
    private notificationService: NotificationService
  ) {}

  ngOnInit() {
    this.isAdmin = this.authService.isAdmin();
    this.loadHotels();
  }

  loadHotels() {
    this.isLoading = true;
    this.hotelService.getAllHotels().subscribe({
      next: (hotels) => {
        this.hotels = hotels;
        this.applyFilters();
        this.isLoading = false;
      },
      error: (error: any) => {
        this.isLoading = false;
        this.notificationService.error('Error', 'Failed to load hotels');
        console.error('Error loading hotels:', error);
      }
    });
  }

  applyFilters() {
    this.filteredHotels = this.hotels.filter(hotel => {
      const matchesCity = !this.searchFilters.city || 
        hotel.city.toLowerCase().includes(this.searchFilters.city.toLowerCase());
      
      const matchesStatus = !this.searchFilters.status || 
        hotel.status === this.searchFilters.status;
      
      const matchesRating = !this.searchFilters.minRating || 
        (hotel.rating && hotel.rating >= this.searchFilters.minRating!);
      
      return matchesCity && matchesStatus && matchesRating;
    });
    
    this.totalPages = Math.ceil(this.filteredHotels.length / this.itemsPerPage);
    this.currentPage = 1;
  }

  onSearch() {
    this.applyFilters();
  }

  clearFilters() {
    this.searchFilters = {};
    this.applyFilters();
  }

  getPaginatedHotels(): Hotel[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredHotels.slice(startIndex, endIndex);
  }

  onPageChange(page: number) {
    this.currentPage = page;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  getPageNumbers(): number[] {
    const pages: number[] = [];
    const maxVisiblePages = 5;
    const startPage = Math.max(1, this.currentPage - Math.floor(maxVisiblePages / 2));
    const endPage = Math.min(this.totalPages, startPage + maxVisiblePages - 1);
    
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
    return pages;
  }

  getStatusBadgeClass(status: string): string {
    switch (status) {
      case 'OPEN':
        return 'badge bg-success';
      case 'CLOSED':
        return 'badge bg-danger';
      case 'UNDER_MAINTENANCE':
        return 'badge bg-warning';
      default:
        return 'badge bg-secondary';
    }
  }

  deleteHotel(hotelId: number) {
    if (confirm('Are you sure you want to delete this hotel?')) {
      this.hotelService.deleteHotel(hotelId).subscribe({
        next: () => {
          this.notificationService.success('Success', 'Hotel deleted successfully');
          this.loadHotels();
        },
        error: (error: any) => {
          this.notificationService.error('Error', 'Failed to delete hotel');
          console.error('Error deleting hotel:', error);
        }
      });
    }
  }

  getStars(rating: number): number[] {
    return Array(Math.floor(rating)).fill(0);
  }

  getEmptyStars(rating: number): number[] {
    return Array(5 - Math.floor(rating)).fill(0);
  }
}
