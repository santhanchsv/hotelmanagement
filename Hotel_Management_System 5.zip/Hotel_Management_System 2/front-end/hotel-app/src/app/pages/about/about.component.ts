import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent {
  teamMembers = [
    {
      name: 'John Smith',
      position: 'CEO & Founder',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop&crop=face',
      bio: 'With over 15 years in hospitality, John founded HotelBooking Pro to revolutionize the hotel booking experience.'
    },
    {
      name: 'Sarah Johnson',
      position: 'CTO',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=300&h=300&fit=crop&crop=face',
      bio: 'Sarah leads our technology team, ensuring our platform delivers seamless experiences across all devices.'
    },
    {
      name: 'Michael Chen',
      position: 'Head of Operations',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&h=300&fit=crop&crop=face',
      bio: 'Michael oversees our hotel partnerships and ensures quality standards across all our properties.'
    },
    {
      name: 'Emily Davis',
      position: 'Customer Success Manager',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300&h=300&fit=crop&crop=face',
      bio: 'Emily is dedicated to ensuring every customer has an exceptional booking and stay experience.'
    }
  ];

  testimonials = [
    {
      name: 'Robert Wilson',
      location: 'New York',
      rating: 5,
      text: 'HotelBooking Pro made my business trip seamless. The interface is intuitive and the customer service is outstanding.'
    },
    {
      name: 'Lisa Martinez',
      location: 'Los Angeles',
      rating: 5,
      text: 'I\'ve been using this platform for family vacations for years. The best rates and the most reliable service.'
    },
    {
      name: 'David Thompson',
      location: 'Chicago',
      rating: 5,
      text: 'The mobile app is fantastic. I can book and manage my stays on the go with ease.'
    }
  ];

  stats = [
    { number: '500+', label: 'Partner Hotels' },
    { number: '50K+', label: 'Happy Customers' },
    { number: '99.9%', label: 'Uptime' },
    { number: '24/7', label: 'Support' }
  ];
}

