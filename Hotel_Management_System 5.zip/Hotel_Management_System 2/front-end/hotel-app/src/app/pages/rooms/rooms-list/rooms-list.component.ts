import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { RoomService } from '../../../core/services/room.service';
import { HotelService } from '../../../core/services/hotel.service';
import { Room, RoomSearchFilters } from '../../../models/room';
import { Hotel } from '../../../models/hotel';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';

@Component({
  selector: 'app-rooms-list',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './rooms-list.component.html',
  styleUrls: ['./rooms-list.component.css']
})
export class RoomsListComponent implements OnInit {
  rooms: Room[] = [];
  filteredRooms: Room[] = [];
  hotels: Hotel[] = [];
  isLoading = false;
  searchFilters: RoomSearchFilters = {};
  currentPage = 1;
  itemsPerPage = 9;
  totalPages = 0;
  isAdmin = false;

  constructor(
    private roomService: RoomService,
    private hotelService: HotelService,
    private authService: AuthService,
    private notificationService: NotificationService
  ) {}

  ngOnInit() {
    this.isAdmin = this.authService.isAdmin();
    this.loadHotels();
    this.loadRooms();
  }

  loadHotels() {
    this.hotelService.getAllHotels().subscribe({
      next: (hotels) => {
        this.hotels = hotels;
      },
      error: (error: any) => {
        console.error('Error loading hotels:', error);
      }
    });
  }

  loadRooms() {
    this.isLoading = true;
    this.roomService.getAllRooms().subscribe({
      next: (rooms) => {
        this.rooms = rooms;
        this.applyFilters();
        this.isLoading = false;
      },
      error: (error: any) => {
        this.isLoading = false;
        this.notificationService.error('Error', 'Failed to load rooms');
        console.error('Error loading rooms:', error);
      }
    });
  }

  applyFilters() {
    this.filteredRooms = this.rooms.filter(room => {
      const matchesHotel = !this.searchFilters.hotelId || 
        room.hotelId === this.searchFilters.hotelId;
      
      const matchesStatus = !this.searchFilters.status || 
        room.status === this.searchFilters.status;
      
      const matchesRoomType = !this.searchFilters.roomTypeId || 
        room.roomTypeId === this.searchFilters.roomTypeId;
      
      return matchesHotel && matchesStatus && matchesRoomType;
    });
    
    this.totalPages = Math.ceil(this.filteredRooms.length / this.itemsPerPage);
    this.currentPage = 1;
  }

  onSearch() {
    this.applyFilters();
  }

  clearFilters() {
    this.searchFilters = {};
    this.applyFilters();
  }

  getPaginatedRooms(): Room[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredRooms.slice(startIndex, endIndex);
  }

  onPageChange(page: number) {
    this.currentPage = page;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  getPageNumbers(): number[] {
    const pages: number[] = [];
    const maxVisiblePages = 5;
    const startPage = Math.max(1, this.currentPage - Math.floor(maxVisiblePages / 2));
    const endPage = Math.min(this.totalPages, startPage + maxVisiblePages - 1);
    
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
    return pages;
  }

  getStatusBadgeClass(status: string): string {
    switch (status) {
      case 'AVAILABLE':
        return 'badge bg-success';
      case 'RESERVED':
        return 'badge bg-warning';
      case 'OCCUPIED':
        return 'badge bg-danger';
      case 'UNDER_MAINTENANCE':
        return 'badge bg-secondary';
      default:
        return 'badge bg-secondary';
    }
  }

  getHotelName(hotelId: number): string {
    const hotel = this.hotels.find(h => h.hotelId === hotelId || h.id === hotelId);
    return hotel ? hotel.name : 'Unknown Hotel';
  }

  deleteRoom(roomId: number) {
    if (confirm('Are you sure you want to delete this room?')) {
      this.roomService.deleteRoom(roomId).subscribe({
        next: () => {
          this.notificationService.success('Success', 'Room deleted successfully');
          this.loadRooms();
        },
        error: (error: any) => {
          this.notificationService.error('Error', 'Failed to delete room');
          console.error('Error deleting room:', error);
        }
      });
    }
  }
}

