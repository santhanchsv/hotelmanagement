import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { RoomService } from '../../../core/services/room.service';
import { HotelService } from '../../../core/services/hotel.service';
import { Room } from '../../../models/room';
import { Hotel } from '../../../models/hotel';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';

@Component({
  selector: 'app-room-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './room-detail.component.html',
  styleUrls: ['./room-detail.component.css']
})
export class RoomDetailComponent implements OnInit {
  room: Room | null = null;
  hotel: Hotel | null = null;
  isLoading = true;
  isAdmin = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private roomService: RoomService,
    private hotelService: HotelService,
    private authService: AuthService,
    private notificationService: NotificationService
  ) {}

  ngOnInit() {
    this.isAdmin = this.authService.isAdmin();
    this.loadRoomDetails();
  }

  loadRoomDetails() {
    const roomId = this.route.snapshot.paramMap.get('id');
    if (roomId) {
      this.roomService.getRoomById(+roomId).subscribe({
        next: (room) => {
          this.room = room;
          if (room.hotelId) {
            this.loadHotel(room.hotelId);
          }
          this.isLoading = false;
        },
        error: (error: any) => {
          this.isLoading = false;
          this.notificationService.error('Error', 'Failed to load room details');
          console.error('Error loading room:', error);
        }
      });
    }
  }

  loadHotel(hotelId: number) {
    this.hotelService.getHotelById(hotelId).subscribe({
      next: (hotel) => {
        this.hotel = hotel;
      },
      error: (error: any) => {
        console.error('Error loading hotel:', error);
      }
    });
  }

  getStatusBadgeClass(status: string): string {
    switch (status) {
      case 'AVAILABLE':
        return 'badge bg-success';
      case 'RESERVED':
        return 'badge bg-warning';
      case 'OCCUPIED':
        return 'badge bg-danger';
      case 'UNDER_MAINTENANCE':
        return 'badge bg-secondary';
      default:
        return 'badge bg-secondary';
    }
  }

  deleteRoom() {
    if (this.room && confirm('Are you sure you want to delete this room?')) {
      this.roomService.deleteRoom(this.room.roomId || this.room.id!).subscribe({
        next: () => {
          this.notificationService.success('Success', 'Room deleted successfully');
          this.router.navigate(['/rooms']);
        },
        error: (error: any) => {
          this.notificationService.error('Error', 'Failed to delete room');
          console.error('Error deleting room:', error);
        }
      });
    }
  }

  bookRoom() {
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/bookings/new'], { 
        queryParams: { 
          hotelId: this.room?.hotelId,
          roomId: this.room?.roomId || this.room?.id
        }
      });
    } else {
      this.router.navigate(['/login'], { 
        queryParams: { returnUrl: this.router.url }
      });
    }
  }

  getRoomPrice(): number {
    // Default pricing based on room type category
    if (!this.room?.roomType) return 100;
    
    switch (this.room.roomType.category) {
      case 'DELUXE': return 200;
      case 'SUITE': return 300;
      case 'EXECUTIVE': return 250;
      case 'STANDARD': return 100;
      default: return 100;
    }
  }

  hasAmenities(): boolean {
    return !!(this.room?.roomType?.amenities && this.room.roomType.amenities.length > 0);
  }
}
