import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HotelService } from '../../core/services/hotel.service';
import { AuthService } from '../../core/services/auth.service';
import { NotificationService } from '../../core/services/notification.service';
import { Hotel } from '../../models/hotel';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  private hotelService = inject(HotelService);
  private authService = inject(AuthService);
  private router = inject(Router);
  private notificationService = inject(NotificationService);
  
  featuredHotels: Hotel[] = [];
  searchCity = '';
  checkInDate = '';
  checkOutDate = '';
  numberOfGuests = 2;
  newsletterEmail = '';
  loading = true;
  favoriteHotels = new Set<number>();

  currentUser$ = this.authService.currentUser$;

  ngOnInit(): void {
    this.setDefaultDates();
    this.loadFeaturedHotels();
    this.loadFavoriteHotels();
  }

  private setDefaultDates(): void {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const dayAfter = new Date(today);
    dayAfter.setDate(dayAfter.getDate() + 2);

    this.checkInDate = tomorrow.toISOString().split('T')[0];
    this.checkOutDate = dayAfter.toISOString().split('T')[0];
  }

          loadFeaturedHotels(): void {
            this.hotelService.getFeaturedHotels().subscribe({
              next: (hotels) => {
                this.featuredHotels = hotels.slice(0, 6);
                this.loading = false;
              },
              error: (error) => {
                console.error('Error loading featured hotels:', error);
                // Fallback to regular hotels
                this.hotelService.getPublicHotels().subscribe({
                  next: (hotels) => {
                    this.featuredHotels = hotels.slice(0, 6);
                    this.loading = false;
                  },
                  error: (fallbackError) => {
                    console.error('Error loading hotels:', fallbackError);
                    this.loading = false;
                  }
                });
              }
            });
          }

  loadFavoriteHotels(): void {
    // Load user's favorite hotels from localStorage or API
    const favorites = localStorage.getItem('favoriteHotels');
    if (favorites) {
      this.favoriteHotels = new Set(JSON.parse(favorites));
    }
  }

  onSearch(): void {
    if (!this.searchCity.trim()) {
      this.notificationService.warning('Search Required', 'Please enter a destination to search for hotels.');
      return;
    }

    const queryParams: any = {
      city: this.searchCity.trim()
    };

    if (this.checkInDate) {
      queryParams.checkInDate = this.checkInDate;
    }

    if (this.checkOutDate) {
      queryParams.checkOutDate = this.checkOutDate;
    }

    if (this.numberOfGuests) {
      queryParams.guests = this.numberOfGuests;
    }

    this.router.navigate(['/hotels'], { queryParams });
  }

  onNewsletterSubmit(): void {
    if (this.newsletterEmail.trim()) {
      this.notificationService.success(
        'Newsletter Subscription',
        'Thank you for subscribing to our newsletter!'
      );
      this.newsletterEmail = '';
    }
  }

  toggleFavorite(hotelId: number): void {
    if (this.favoriteHotels.has(hotelId)) {
      this.favoriteHotels.delete(hotelId);
    } else {
      this.favoriteHotels.add(hotelId);
    }

    // Save to localStorage
    localStorage.setItem('favoriteHotels', JSON.stringify([...this.favoriteHotels]));

    // Show notification
    const message = this.favoriteHotels.has(hotelId) 
      ? 'Hotel added to favorites!' 
      : 'Hotel removed from favorites!';
    
    this.notificationService.info('Favorites', message);
  }

  isFavorite(hotelId: number): boolean {
    return this.favoriteHotels.has(hotelId);
  }

  getStatusBadgeClass(status: string): string {
    switch (status) {
      case 'OPEN': return 'badge ok';
      case 'CLOSED': return 'badge bad';
      case 'UNDER_MAINTENANCE': return 'badge warn';
      default: return 'badge';
    }
  }

  getStatusText(status: string): string {
    switch (status) {
      case 'OPEN': return 'Open';
      case 'CLOSED': return 'Closed';
      case 'UNDER_MAINTENANCE': return 'Under Maintenance';
      default: return status;
    }
  }
}
