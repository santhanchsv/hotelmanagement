import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { AboutComponent } from './pages/about/about.component';
import { LoginComponent } from './pages/auth/login/login.component';
import { SignupComponent } from './pages/auth/signup/signup.component';
import { ForgotPasswordComponent } from './pages/auth/forgot-password/forgot-password.component';
import { HotelsListComponent } from './pages/hotels/hotels-list/hotels-list.component';
import { HotelDetailComponent } from './pages/hotels/hotel-detail/hotel-detail.component';
import { RoomsListComponent } from './pages/rooms/rooms-list/rooms-list.component';
import { RoomDetailComponent } from './pages/rooms/room-detail/room-detail.component';
import { BookingsListComponent } from './pages/bookings/bookings-list/bookings-list.component';
import { BookingFormComponent } from './pages/bookings/booking-form/booking-form.component';
import { BookingDetailComponent } from './pages/bookings/booking-detail/booking-detail.component';
import { ProfileComponent } from './pages/users/profile/profile.component';
import { UserListComponent } from './pages/users/user-list/user-list.component';
import { AddHotelComponent } from './features/admin/add-hotel/add-hotel.component';
import { HotelEditComponent } from './features/admin/hotel-edit/hotel-edit.component';
import { RoomTypeListComponent } from './features/admin/roomtype-list/roomtype-list.component';
import { AddRoomTypeComponent } from './features/admin/roomtype-add/roomtype-add.component';
import { AddRoomComponent } from './features/admin/add-room/add-room.component';
import { EditRoomComponent } from './features/admin/edit-room/edit-room.component';
import { AuthGuard } from './core/guards/auth.guard';
import { GuestGuard } from './core/guards/guest.guard';
import { RoleGuard } from './core/guards/role.guard';

export const routes: Routes = [
    // Public Routes
    { path: '', component: HomeComponent },
    { path: 'about', component: AboutComponent },
    { path: 'hotels', component: HotelsListComponent },
    { path: 'hotels/:id', component: HotelDetailComponent },
    { path: 'rooms', component: RoomsListComponent },
    { path: 'rooms/:id', component: RoomDetailComponent },
    
    // Auth Routes (Guest only)
    { 
        path: 'login', 
        component: LoginComponent,
        canActivate: [GuestGuard]
    },
    { 
        path: 'signup', 
        component: SignupComponent,
        canActivate: [GuestGuard]
    },
    { 
        path: 'forgot-password', 
        component: ForgotPasswordComponent,
        canActivate: [GuestGuard]
    },
    
    // Protected Routes (Authenticated users)
    { 
        path: 'bookings', 
        component: BookingsListComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'bookings/new', 
        component: BookingFormComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'bookings/:id', 
        component: BookingDetailComponent,
        canActivate: [AuthGuard]
    },
    { 
        path: 'profile', 
        component: ProfileComponent,
        canActivate: [AuthGuard]
    },
    
    // Admin Routes
    { 
        path: 'admin/hotels', 
        component: HotelsListComponent,
        canActivate: [AuthGuard, RoleGuard],
        data: { roles: ['ADMIN', 'STAFF'] }
    },
    { 
        path: 'admin/hotels/add', 
        component: AddHotelComponent,
        canActivate: [AuthGuard, RoleGuard],
        data: { roles: ['ADMIN', 'STAFF'] }
    },
    { 
        path: 'admin/hotels/edit/:id', 
        component: HotelEditComponent,
        canActivate: [AuthGuard, RoleGuard],
        data: { roles: ['ADMIN', 'STAFF'] }
    },
    { 
        path: 'admin/hotels/:hotelId/roomtypes', 
        component: RoomTypeListComponent,
        canActivate: [AuthGuard, RoleGuard],
        data: { roles: ['ADMIN', 'STAFF'] }
    },
    { 
        path: 'admin/hotels/:hotelId/roomtypes/add', 
        component: AddRoomTypeComponent,
        canActivate: [AuthGuard, RoleGuard],
        data: { roles: ['ADMIN', 'STAFF'] }
    },
    { 
        path: 'admin/rooms', 
        component: RoomsListComponent,
        canActivate: [AuthGuard, RoleGuard],
        data: { roles: ['ADMIN', 'STAFF'] }
    },
    { 
        path: 'admin/rooms/add', 
        component: AddRoomComponent,
        canActivate: [AuthGuard, RoleGuard],
        data: { roles: ['ADMIN', 'STAFF'] }
    },
    { 
        path: 'admin/rooms/edit/:id', 
        component: EditRoomComponent,
        canActivate: [AuthGuard, RoleGuard],
        data: { roles: ['ADMIN', 'STAFF'] }
    },
    { 
        path: 'admin/users', 
        component: UserListComponent,
        canActivate: [AuthGuard, RoleGuard],
        data: { roles: ['ADMIN'] }
    },
    
    // Redirects
    { path: '**', redirectTo: '' }
];