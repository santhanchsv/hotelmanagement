#!/bin/bash

# Hotel Management System - Microservices Stop Script

echo "Stopping Hotel Management System Microservices..."

# Function to stop a service
stop_service() {
    local service_name=$1
    local pid_file="logs/${service_name}.pid"
    
    if [ -f "$pid_file" ]; then
        local pid=$(cat "$pid_file")
        echo "Stopping $service_name (PID: $pid)..."
        kill $pid 2>/dev/null
        rm "$pid_file"
        echo "$service_name stopped."
    else
        echo "$service_name PID file not found. Service may not be running."
    fi
}

# Stop services
stop_service "booking-service"
stop_service "user-service"
stop_service "catalog-service"
stop_service "api-gateway"
stop_service "discovery-server"

echo ""
echo "All services have been stopped."
echo "Log files are preserved in the logs/ directory."
