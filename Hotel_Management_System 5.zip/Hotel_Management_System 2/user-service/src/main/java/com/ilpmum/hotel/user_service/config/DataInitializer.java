package com.ilpmum.hotel.user_service.config;

import com.ilpmum.hotel.user_service.model.User;
import com.ilpmum.hotel.user_service.repo.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {
    
    private final UserRepository userRepository;
    
    public DataInitializer(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    @Override
    public void run(String... args) throws Exception {
        // Initialize sample data
        initializeSampleData();
    }
    
    private void initializeSampleData() {
        // Create sample users - Only ADMIN and CUSTOMER roles
        User admin = new User("Admin User", "admin@hotel.com", "+91-9876543210", 
                            "hashed_password_123", User.UserRole.ADMIN);
        admin.setLoyaltyPoints(0);
        userRepository.save(admin);
        
        User customer1 = new User("Rajesh Kumar", "rajesh@gmail.com", "+91-9876543213", 
                                 "hashed_password_101", User.UserRole.CUSTOMER);
        customer1.setLoyaltyPoints(150);
        userRepository.save(customer1);
        
        User customer2 = new User("Priya Sharma", "priya@gmail.com", "+91-9876543214", 
                                 "hashed_password_102", User.UserRole.CUSTOMER);
        customer2.setLoyaltyPoints(300);
        userRepository.save(customer2);
        
        User customer3 = new User("Amit Patel", "amit@gmail.com", "+91-9876543215", 
                                 "hashed_password_103", User.UserRole.CUSTOMER);
        customer3.setLoyaltyPoints(75);
        userRepository.save(customer3);
        
        User customer4 = new User("Sneha Singh", "sneha@gmail.com", "+91-9876543216", 
                                 "hashed_password_104", User.UserRole.CUSTOMER);
        customer4.setLoyaltyPoints(500);
        userRepository.save(customer4);
        
        User customer5 = new User("Vikram Reddy", "vikram@gmail.com", "+91-9876543217", 
                                 "hashed_password_105", User.UserRole.CUSTOMER);
        customer5.setLoyaltyPoints(200);
        userRepository.save(customer5);
        
        User customer6 = new User("Anita Desai", "anita@gmail.com", "+91-9876543218", 
                                 "hashed_password_106", User.UserRole.CUSTOMER);
        customer6.setLoyaltyPoints(100);
        userRepository.save(customer6);
        
        User customer7 = new User("Ravi Joshi", "ravi@gmail.com", "+91-9876543219", 
                                 "hashed_password_107", User.UserRole.CUSTOMER);
        customer7.setLoyaltyPoints(350);
        userRepository.save(customer7);
    }
}