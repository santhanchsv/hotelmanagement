package com.ilpmum.hotel.user_service.repo;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ilpmum.hotel.user_service.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
    
    // Find user by email
    Optional<User> findByEmail(String email);
    
    // Check if email exists
    boolean existsByEmail(String email);
    
    // Find users by role
    List<User> findByRole(User.UserRole role);
    
    // Find users by phone number
    Optional<User> findByPhoneNumber(String phoneNumber);
    
    // Find users with loyalty points above threshold
    List<User> findByLoyaltyPointsGreaterThan(Integer minPoints);
    
    // Find users by name (partial match)
    List<User> findByFullNameContainingIgnoreCase(String name);
    
    // Find users created after a specific date
    List<User> findByCreatedAtAfter(java.time.LocalDateTime date);
}
