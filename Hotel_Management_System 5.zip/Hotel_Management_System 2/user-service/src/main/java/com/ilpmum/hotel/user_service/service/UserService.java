package com.ilpmum.hotel.user_service.service;

import com.ilpmum.hotel.user_service.model.User;
import com.ilpmum.hotel.user_service.repo.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserService {
    
    private final UserRepository userRepository;
    
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    
    public Optional<User> getUserById(Long userId) {
        return userRepository.findById(userId);
    }
    
    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    public User createUser(User user) {
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new IllegalArgumentException("User with email " + user.getEmail() + " already exists");
        }
        
        if (user.getRole() == null) {
            user.setRole(User.UserRole.CUSTOMER);
        }
        
        if (user.getLoyaltyPoints() == null) {
            user.setLoyaltyPoints(0);
        }
        
        return userRepository.save(user);
    }
    
    public User updateUser(Long userId, User updatedUser) {
        return userRepository.findById(userId)
                .map(existing -> {
                    existing.setFullName(updatedUser.getFullName());
                    existing.setEmail(updatedUser.getEmail());
                    existing.setPhoneNumber(updatedUser.getPhoneNumber());
                    existing.setRole(updatedUser.getRole());
                    existing.setLoyaltyPoints(updatedUser.getLoyaltyPoints());
                    return userRepository.save(existing);
                })
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }
    
    public void deleteUser(Long userId) {
        if (!userRepository.existsById(userId)) {
            throw new IllegalArgumentException("User not found");
        }
        userRepository.deleteById(userId);
    }
    
    public List<User> getUsersByRole(User.UserRole role) {
        return userRepository.findByRole(role);
    }
    
    public User updateLoyaltyPoints(Long userId, Integer points) {
        return userRepository.findById(userId)
                .map(user -> {
                    user.setLoyaltyPoints(points);
                    return userRepository.save(user);
                })
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }
    
    public User addLoyaltyPoints(Long userId, Integer points) {
        return userRepository.findById(userId)
                .map(user -> {
                    Integer currentPoints = user.getLoyaltyPoints() != null ? user.getLoyaltyPoints() : 0;
                    user.setLoyaltyPoints(currentPoints + points);
                    return userRepository.save(user);
                })
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }
    
    public User updateLastLogin(Long userId) {
        return userRepository.findById(userId)
                .map(user -> {
                    user.setLastLoginAt(LocalDateTime.now());
                    return userRepository.save(user);
                })
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }
    
    public List<User> getUsersWithLoyaltyPointsAbove(Integer minPoints) {
        return userRepository.findByLoyaltyPointsGreaterThan(minPoints);
    }
    
    public List<User> searchUsersByName(String name) {
        return userRepository.findByFullNameContainingIgnoreCase(name);
    }
    
    public List<User> getUsersCreatedAfter(LocalDateTime date) {
        return userRepository.findByCreatedAtAfter(date);
    }
    
    public boolean userExists(String email) {
        return userRepository.existsByEmail(email);
    }
    
    public boolean userExists(Long userId) {
        return userRepository.existsById(userId);
    }
}
