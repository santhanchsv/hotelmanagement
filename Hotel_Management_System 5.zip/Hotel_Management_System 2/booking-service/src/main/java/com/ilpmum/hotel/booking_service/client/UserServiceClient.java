package com.ilpmum.hotel.booking_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "USER-SERVICE")
public interface UserServiceClient {
    
    @GetMapping("/api/user/users/{userId}")
    UserInfo getUserById(@PathVariable("userId") Long userId);
    
    @GetMapping("/api/user/users/email/{email}")
    UserInfo getUserByEmail(@PathVariable("email") String email);
    
    // DTO for data transfer
    class UserInfo {
        private Long userId;
        private String fullName;
        private String email;
        private String phoneNumber;
        private String role;
        private Integer loyaltyPoints;
        private String createdAt;
        private String lastLoginAt;
        
        // Constructors, getters, and setters
        public UserInfo() {}
        
        public UserInfo(Long userId, String fullName, String email, String phoneNumber, 
                       String role, Integer loyaltyPoints, String createdAt, String lastLoginAt) {
            this.userId = userId;
            this.fullName = fullName;
            this.email = email;
            this.phoneNumber = phoneNumber;
            this.role = role;
            this.loyaltyPoints = loyaltyPoints;
            this.createdAt = createdAt;
            this.lastLoginAt = lastLoginAt;
        }
        
        // Getters and setters
        public Long getUserId() { return userId; }
        public void setUserId(Long userId) { this.userId = userId; }
        
        public String getFullName() { return fullName; }
        public void setFullName(String fullName) { this.fullName = fullName; }
        
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        
        public String getPhoneNumber() { return phoneNumber; }
        public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
        
        public String getRole() { return role; }
        public void setRole(String role) { this.role = role; }
        
        public Integer getLoyaltyPoints() { return loyaltyPoints; }
        public void setLoyaltyPoints(Integer loyaltyPoints) { this.loyaltyPoints = loyaltyPoints; }
        
        public String getCreatedAt() { return createdAt; }
        public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
        
        public String getLastLoginAt() { return lastLoginAt; }
        public void setLastLoginAt(String lastLoginAt) { this.lastLoginAt = lastLoginAt; }
    }
}
