package com.ilpmum.hotel.booking_service.service;

import com.ilpmum.hotel.booking_service.model.Booking;
import com.ilpmum.hotel.booking_service.repo.BookingRepository;
import com.ilpmum.hotel.booking_service.client.CatalogServiceClient;
import com.ilpmum.hotel.booking_service.client.UserServiceClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class BookingService {
    
    private final BookingRepository bookingRepository;
    private final CatalogServiceClient catalogServiceClient;
    private final UserServiceClient userServiceClient;
    
    public BookingService(BookingRepository bookingRepository, 
                         CatalogServiceClient catalogServiceClient,
                         UserServiceClient userServiceClient) {
        this.bookingRepository = bookingRepository;
        this.catalogServiceClient = catalogServiceClient;
        this.userServiceClient = userServiceClient;
    }
    
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }
    
    public Optional<Booking> getBookingById(Long bookingId) {
        return bookingRepository.findById(bookingId);
    }
    
    public List<Booking> getBookingsByUser(Long userId) {
        return bookingRepository.findByUserId(userId);
    }
    
    public List<Booking> getBookingsByHotel(Long hotelId) {
        return bookingRepository.findByHotelId(hotelId);
    }
    
    public Booking createBooking(Booking booking) {
        // Validate user exists
        UserServiceClient.UserInfo user = userServiceClient.getUserById(booking.getUserId());
        if (user == null) {
            throw new IllegalArgumentException("User not found");
        }
        
        // Validate hotel exists
        CatalogServiceClient.HotelInfo hotel = catalogServiceClient.getHotelById(booking.getHotelId());
        if (hotel == null) {
            throw new IllegalArgumentException("Hotel not found");
        }
        
        // Validate room exists and is available
        CatalogServiceClient.RoomInfo room = catalogServiceClient.getRoomById(booking.getRoomId());
        if (room == null) {
            throw new IllegalArgumentException("Room not found");
        }
        
        if (!"AVAILABLE".equals(room.getStatus())) {
            throw new IllegalArgumentException("Room is not available");
        }
        
        // Check for conflicting bookings
        List<Booking> conflictingBookings = bookingRepository.findConflictingBookings(
                booking.getRoomId(), booking.getCheckInDate(), booking.getCheckOutDate());
        
        if (!conflictingBookings.isEmpty()) {
            throw new IllegalArgumentException("Room is already booked for the selected dates");
        }
        
        // Calculate total amount if not provided
        if (booking.getTotalAmount() == null) {
            CatalogServiceClient.RoomTypeInfo roomType = catalogServiceClient.getRoomTypeById(room.getRoomTypeId());
            if (roomType != null) {
                long days = ChronoUnit.DAYS.between(booking.getCheckInDate(), booking.getCheckOutDate());
                BigDecimal totalAmount = roomType.getPricePerDay().multiply(BigDecimal.valueOf(days));
                booking.setTotalAmount(totalAmount);
            }
        }
        
        return bookingRepository.save(booking);
    }
    
    public Booking updateBooking(Long bookingId, Booking updatedBooking) {
        return bookingRepository.findById(bookingId)
                .map(existing -> {
                    existing.setCheckInDate(updatedBooking.getCheckInDate());
                    existing.setCheckOutDate(updatedBooking.getCheckOutDate());
                    existing.setStatus(updatedBooking.getStatus());
                    existing.setPaymentStatus(updatedBooking.getPaymentStatus());
                    existing.setSpecialRequests(updatedBooking.getSpecialRequests());
                    return bookingRepository.save(existing);
                })
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
    }
    
    public Booking updateBookingStatus(Long bookingId, Booking.BookingStatus status) {
        return bookingRepository.findById(bookingId)
                .map(booking -> {
                    booking.setStatus(status);
                    
                    // Update timestamps based on status
                    if (status == Booking.BookingStatus.CHECKED_IN) {
                        booking.setCheckInTime(java.time.LocalDateTime.now());
                    } else if (status == Booking.BookingStatus.CHECKED_OUT) {
                        booking.setCheckOutTime(java.time.LocalDateTime.now());
                    }
                    
                    return bookingRepository.save(booking);
                })
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
    }
    
    public Booking updatePaymentStatus(Long bookingId, Booking.PaymentStatus paymentStatus) {
        return bookingRepository.findById(bookingId)
                .map(booking -> {
                    booking.setPaymentStatus(paymentStatus);
                    return bookingRepository.save(booking);
                })
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
    }
    
    public void cancelBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
        
        if (booking.getStatus() == Booking.BookingStatus.CHECKED_IN) {
            throw new IllegalArgumentException("Cannot cancel a checked-in booking");
        }
        
        booking.setStatus(Booking.BookingStatus.CANCELLED);
        bookingRepository.save(booking);
    }
    
    public List<Booking> getBookingsByStatus(Booking.BookingStatus status) {
        return bookingRepository.findByStatus(status);
    }
    
    public List<Booking> getBookingsByDateRange(LocalDate startDate, LocalDate endDate) {
        return bookingRepository.findByCheckInDateBetween(startDate, endDate);
    }
    
    public List<Booking> getConflictingBookings(Long roomId, LocalDate checkInDate, LocalDate checkOutDate) {
        return bookingRepository.findConflictingBookings(roomId, checkInDate, checkOutDate);
    }
    
    public long getBookingCountByStatus(Booking.BookingStatus status) {
        return bookingRepository.countByStatus(status);
    }
}
