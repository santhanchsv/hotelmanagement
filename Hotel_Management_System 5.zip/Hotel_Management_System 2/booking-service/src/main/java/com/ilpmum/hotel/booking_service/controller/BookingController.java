package com.ilpmum.hotel.booking_service.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ilpmum.hotel.booking_service.model.Booking;
import com.ilpmum.hotel.booking_service.repo.BookingRepository;
import com.ilpmum.hotel.booking_service.client.CatalogServiceClient;
import com.ilpmum.hotel.booking_service.client.UserServiceClient;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/booking/bookings")
public class BookingController {
    
    private final BookingRepository bookingRepository;
    private final CatalogServiceClient catalogServiceClient;
    private final UserServiceClient userServiceClient;
    
    public BookingController(BookingRepository bookingRepository, 
                           CatalogServiceClient catalogServiceClient,
                           UserServiceClient userServiceClient) {
        this.bookingRepository = bookingRepository;
        this.catalogServiceClient = catalogServiceClient;
        this.userServiceClient = userServiceClient;
    }
    
    @GetMapping
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }
    
    @GetMapping("/{bookingId}")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long bookingId) {
        return bookingRepository.findById(bookingId)
                .map(booking -> ResponseEntity.ok(booking))
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/user/{userId}")
    public List<Booking> getBookingsByUser(@PathVariable Long userId) {
        return bookingRepository.findByUserId(userId);
    }
    
    @GetMapping("/hotel/{hotelId}")
    public List<Booking> getBookingsByHotel(@PathVariable Long hotelId) {
        return bookingRepository.findByHotelId(hotelId);
    }
    
    @PostMapping
    public ResponseEntity<?> createBooking(@RequestBody Booking booking) {
        try {
            // Validate user exists
            UserServiceClient.UserInfo user = userServiceClient.getUserById(booking.getUserId());
            if (user == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("User not found");
            }
            
            // Validate hotel exists
            CatalogServiceClient.HotelInfo hotel = catalogServiceClient.getHotelById(booking.getHotelId());
            if (hotel == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Hotel not found");
            }
            
            // Validate room exists and is available
            CatalogServiceClient.RoomInfo room = catalogServiceClient.getRoomById(booking.getRoomId());
            if (room == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Room not found");
            }
            
            if (!"AVAILABLE".equals(room.getStatus())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Room is not available");
            }
            
            // Check for conflicting bookings
            List<Booking> conflictingBookings = bookingRepository.findConflictingBookings(
                    booking.getRoomId(), booking.getCheckInDate(), booking.getCheckOutDate());
            
            if (!conflictingBookings.isEmpty()) {
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body("Room is already booked for the selected dates");
            }
            
            // Calculate total amount if not provided
            if (booking.getTotalAmount() == null) {
                CatalogServiceClient.RoomTypeInfo roomType = catalogServiceClient.getRoomTypeById(room.getRoomTypeId());
                if (roomType != null) {
                    long days = ChronoUnit.DAYS.between(booking.getCheckInDate(), booking.getCheckOutDate());
                    BigDecimal totalAmount = roomType.getPricePerDay().multiply(BigDecimal.valueOf(days));
                    booking.setTotalAmount(totalAmount);
                }
            }
            
            Booking savedBooking = bookingRepository.save(booking);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedBooking);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error creating booking: " + e.getMessage());
        }
    }
    
    @PutMapping("/{bookingId}")
    public ResponseEntity<Booking> updateBooking(@PathVariable Long bookingId, @RequestBody Booking updatedBooking) {
        return bookingRepository.findById(bookingId)
                .map(existing -> {
                    existing.setCheckInDate(updatedBooking.getCheckInDate());
                    existing.setCheckOutDate(updatedBooking.getCheckOutDate());
                    existing.setStatus(updatedBooking.getStatus());
                    existing.setPaymentStatus(updatedBooking.getPaymentStatus());
                    existing.setSpecialRequests(updatedBooking.getSpecialRequests());
                    return ResponseEntity.ok(bookingRepository.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PutMapping("/{bookingId}/status")
    public ResponseEntity<Booking> updateBookingStatus(@PathVariable Long bookingId, @RequestParam String status) {
        return bookingRepository.findById(bookingId)
                .map(booking -> {
                    try {
                        Booking.BookingStatus bookingStatus = Booking.BookingStatus.valueOf(status.toUpperCase());
                        booking.setStatus(bookingStatus);
                        
                        // Update timestamps based on status
                        if (bookingStatus == Booking.BookingStatus.CHECKED_IN) {
                            booking.setCheckInTime(java.time.LocalDateTime.now());
                        } else if (bookingStatus == Booking.BookingStatus.CHECKED_OUT) {
                            booking.setCheckOutTime(java.time.LocalDateTime.now());
                        }
                        
                        return ResponseEntity.ok(bookingRepository.save(booking));
                    } catch (IllegalArgumentException e) {
                        return ResponseEntity.badRequest().build();
                    }
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PutMapping("/{bookingId}/payment")
    public ResponseEntity<Booking> updatePaymentStatus(@PathVariable Long bookingId, @RequestParam String paymentStatus) {
        return bookingRepository.findById(bookingId)
                .map(booking -> {
                    try {
                        Booking.PaymentStatus payment = Booking.PaymentStatus.valueOf(paymentStatus.toUpperCase());
                        booking.setPaymentStatus(payment);
                        return ResponseEntity.ok(bookingRepository.save(booking));
                    } catch (IllegalArgumentException e) {
                        return ResponseEntity.badRequest().build();
                    }
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    @DeleteMapping("/{bookingId}")
    public ResponseEntity<String> cancelBooking(@PathVariable Long bookingId) {
        return bookingRepository.findById(bookingId)
                .map(booking -> {
                    if (booking.getStatus() == Booking.BookingStatus.CHECKED_IN) {
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                                .body("Cannot cancel a checked-in booking");
                    }
                    
                    booking.setStatus(Booking.BookingStatus.CANCELLED);
                    bookingRepository.save(booking);
                    return ResponseEntity.ok("Booking cancelled successfully");
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/status/{status}")
    public List<Booking> getBookingsByStatus(@PathVariable String status) {
        try {
            Booking.BookingStatus bookingStatus = Booking.BookingStatus.valueOf(status.toUpperCase());
            return bookingRepository.findByStatus(bookingStatus);
        } catch (IllegalArgumentException e) {
            return List.of();
        }
    }
    
    @GetMapping("/date-range")
    public List<Booking> getBookingsByDateRange(@RequestParam LocalDate startDate, @RequestParam LocalDate endDate) {
        return bookingRepository.findByCheckInDateBetween(startDate, endDate);
    }
}
