package com.ilpmum.hotel.booking_service.config;

import com.ilpmum.hotel.booking_service.model.Booking;
import com.ilpmum.hotel.booking_service.repo.BookingRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Component
public class DataInitializer implements CommandLineRunner {
    
    private final BookingRepository bookingRepository;
    
    public DataInitializer(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }
    
    @Override
    public void run(String... args) throws Exception {
        // Initialize sample data
        initializeSampleData();
    }
    
    private void initializeSampleData() {
        // Create sample bookings
        Booking booking1 = new Booking(4L, 1L, 1L, 
                                     LocalDate.now().plusDays(1), 
                                     LocalDate.now().plusDays(3), 
                                     BigDecimal.valueOf(5000.0), 
                                     "Late check-in requested");
        booking1.setStatus(Booking.BookingStatus.CONFIRMED);
        booking1.setPaymentStatus(Booking.PaymentStatus.PAID);
        booking1.setReservationDate(LocalDateTime.now().minusDays(5));
        bookingRepository.save(booking1);
        
        Booking booking2 = new Booking(5L, 1L, 2L, 
                                     LocalDate.now().plusDays(2), 
                                     LocalDate.now().plusDays(4), 
                                     BigDecimal.valueOf(9000.0), 
                                     "Anniversary celebration");
        booking2.setStatus(Booking.BookingStatus.PENDING);
        booking2.setPaymentStatus(Booking.PaymentStatus.UNPAID);
        booking2.setReservationDate(LocalDateTime.now().minusDays(2));
        bookingRepository.save(booking2);
        
        Booking booking3 = new Booking(6L, 2L, 11L, 
                                     LocalDate.now().minusDays(1), 
                                     LocalDate.now().plusDays(1), 
                                     BigDecimal.valueOf(4000.0), 
                                     "Business trip");
        booking3.setStatus(Booking.BookingStatus.CHECKED_IN);
        booking3.setPaymentStatus(Booking.PaymentStatus.PAID);
        booking3.setReservationDate(LocalDateTime.now().minusDays(7));
        booking3.setCheckInTime(LocalDateTime.now().minusDays(1).plusHours(2));
        bookingRepository.save(booking3);
        
        Booking booking4 = new Booking(7L, 3L, 21L, 
                                     LocalDate.now().minusDays(3), 
                                     LocalDate.now().minusDays(1), 
                                     BigDecimal.valueOf(11000.0), 
                                     "Honeymoon trip");
        booking4.setStatus(Booking.BookingStatus.CHECKED_OUT);
        booking4.setPaymentStatus(Booking.PaymentStatus.PAID);
        booking4.setReservationDate(LocalDateTime.now().minusDays(10));
        booking4.setCheckInTime(LocalDateTime.now().minusDays(3).plusHours(3));
        booking4.setCheckOutTime(LocalDateTime.now().minusDays(1).plusHours(11));
        bookingRepository.save(booking4);
        
        Booking booking5 = new Booking(8L, 1L, 3L, 
                                     LocalDate.now().plusDays(5), 
                                     LocalDate.now().plusDays(7), 
                                     BigDecimal.valueOf(16000.0), 
                                     "Family vacation");
        booking5.setStatus(Booking.BookingStatus.CONFIRMED);
        booking5.setPaymentStatus(Booking.PaymentStatus.PAID);
        booking5.setReservationDate(LocalDateTime.now().minusDays(1));
        bookingRepository.save(booking5);
        
        Booking booking6 = new Booking(9L, 2L, 12L, 
                                     LocalDate.now().plusDays(3), 
                                     LocalDate.now().plusDays(5), 
                                     BigDecimal.valueOf(6000.0), 
                                     "Weekend getaway");
        booking6.setStatus(Booking.BookingStatus.CANCELLED);
        booking6.setPaymentStatus(Booking.PaymentStatus.REFUNDED);
        booking6.setReservationDate(LocalDateTime.now().minusDays(3));
        bookingRepository.save(booking6);
    }
}
