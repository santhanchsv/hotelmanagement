package com.ilpmum.hotel.booking_service.repo;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.ilpmum.hotel.booking_service.model.Booking;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    
    // Find bookings by user
    List<Booking> findByUserId(Long userId);
    
    // Find bookings by hotel
    List<Booking> findByHotelId(Long hotelId);
    
    // Find bookings by room
    List<Booking> findByRoomId(Long roomId);
    
    // Find bookings by status
    List<Booking> findByStatus(Booking.BookingStatus status);
    
    // Find bookings by payment status
    List<Booking> findByPaymentStatus(Booking.PaymentStatus paymentStatus);
    
    // Find bookings by date range
    List<Booking> findByCheckInDateBetween(LocalDate startDate, LocalDate endDate);
    List<Booking> findByCheckOutDateBetween(LocalDate startDate, LocalDate endDate);
    
    // Find bookings for a specific room in a date range
    @Query("SELECT b FROM Booking b WHERE b.roomId = :roomId AND " +
           "((b.checkInDate <= :checkOutDate AND b.checkOutDate >= :checkInDate) OR " +
           "(b.checkInDate <= :checkInDate AND b.checkOutDate >= :checkInDate) OR " +
           "(b.checkInDate <= :checkOutDate AND b.checkOutDate >= :checkOutDate)) AND " +
           "b.status IN ('CONFIRMED', 'CHECKED_IN')")
    List<Booking> findConflictingBookings(@Param("roomId") Long roomId, 
                                         @Param("checkInDate") LocalDate checkInDate, 
                                         @Param("checkOutDate") LocalDate checkOutDate);
    
    // Find bookings by user and status
    List<Booking> findByUserIdAndStatus(Long userId, Booking.BookingStatus status);
    
    // Find bookings by hotel and status
    List<Booking> findByHotelIdAndStatus(Long hotelId, Booking.BookingStatus status);
    
    // Find bookings created after a specific date
    List<Booking> findByReservationDateAfter(java.time.LocalDateTime date);
    
    // Count bookings by status
    long countByStatus(Booking.BookingStatus status);
    
    // Find bookings with special requests
    List<Booking> findBySpecialRequestsIsNotNull();
}
