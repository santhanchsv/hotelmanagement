package com.ilpmum.hotel.booking_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "CATALOG-SERVICE")
public interface CatalogServiceClient {
    
    @GetMapping("/api/admin/hotels/{hotelId}")
    HotelInfo getHotelById(@PathVariable("hotelId") Long hotelId);
    
    @GetMapping("/api/admin/rooms/{roomId}")
    RoomInfo getRoomById(@PathVariable("roomId") Long roomId);
    
    @GetMapping("/api/admin/room-types/{roomTypeId}")
    RoomTypeInfo getRoomTypeById(@PathVariable("roomTypeId") Long roomTypeId);
    
    // DTOs for data transfer
    class HotelInfo {
        private Long hotelId;
        private String name;
        private String city;
        private String address;
        private String status;
        private Double rating;
        private Integer totalRooms;
        private Integer availableRooms;
        
        // Constructors, getters, and setters
        public HotelInfo() {}
        
        public HotelInfo(Long hotelId, String name, String city, String address, String status, 
                        Double rating, Integer totalRooms, Integer availableRooms) {
            this.hotelId = hotelId;
            this.name = name;
            this.city = city;
            this.address = address;
            this.status = status;
            this.rating = rating;
            this.totalRooms = totalRooms;
            this.availableRooms = availableRooms;
        }
        
        // Getters and setters
        public Long getHotelId() { return hotelId; }
        public void setHotelId(Long hotelId) { this.hotelId = hotelId; }
        
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        
        public String getCity() { return city; }
        public void setCity(String city) { this.city = city; }
        
        public String getAddress() { return address; }
        public void setAddress(String address) { this.address = address; }
        
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        
        public Double getRating() { return rating; }
        public void setRating(Double rating) { this.rating = rating; }
        
        public Integer getTotalRooms() { return totalRooms; }
        public void setTotalRooms(Integer totalRooms) { this.totalRooms = totalRooms; }
        
        public Integer getAvailableRooms() { return availableRooms; }
        public void setAvailableRooms(Integer availableRooms) { this.availableRooms = availableRooms; }
    }
    
    class RoomInfo {
        private Long roomId;
        private Long hotelId;
        private Long roomTypeId;
        private String roomNumber;
        private String status;
        private Integer floorNumber;
        private String lastMaintenanceDate;
        
        // Constructors, getters, and setters
        public RoomInfo() {}
        
        public RoomInfo(Long roomId, Long hotelId, Long roomTypeId, String roomNumber, 
                       String status, Integer floorNumber, String lastMaintenanceDate) {
            this.roomId = roomId;
            this.hotelId = hotelId;
            this.roomTypeId = roomTypeId;
            this.roomNumber = roomNumber;
            this.status = status;
            this.floorNumber = floorNumber;
            this.lastMaintenanceDate = lastMaintenanceDate;
        }
        
        // Getters and setters
        public Long getRoomId() { return roomId; }
        public void setRoomId(Long roomId) { this.roomId = roomId; }
        
        public Long getHotelId() { return hotelId; }
        public void setHotelId(Long hotelId) { this.hotelId = hotelId; }
        
        public Long getRoomTypeId() { return roomTypeId; }
        public void setRoomTypeId(Long roomTypeId) { this.roomTypeId = roomTypeId; }
        
        public String getRoomNumber() { return roomNumber; }
        public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
        
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        
        public Integer getFloorNumber() { return floorNumber; }
        public void setFloorNumber(Integer floorNumber) { this.floorNumber = floorNumber; }
        
        public String getLastMaintenanceDate() { return lastMaintenanceDate; }
        public void setLastMaintenanceDate(String lastMaintenanceDate) { this.lastMaintenanceDate = lastMaintenanceDate; }
    }
    
    class RoomTypeInfo {
        private Long roomTypeId;
        private Long hotelId;
        private String category;
        private String description;
        private Integer capacity;
        private Double pricePerDay;
        private java.util.List<String> amenities;
        
        // Constructors, getters, and setters
        public RoomTypeInfo() {}
        
        public RoomTypeInfo(Long roomTypeId, Long hotelId, String category, String description, 
                           Integer capacity, Double pricePerDay, java.util.List<String> amenities) {
            this.roomTypeId = roomTypeId;
            this.hotelId = hotelId;
            this.category = category;
            this.description = description;
            this.capacity = capacity;
            this.pricePerDay = pricePerDay;
            this.amenities = amenities;
        }
        
        // Getters and setters
        public Long getRoomTypeId() { return roomTypeId; }
        public void setRoomTypeId(Long roomTypeId) { this.roomTypeId = roomTypeId; }
        
        public Long getHotelId() { return hotelId; }
        public void setHotelId(Long hotelId) { this.hotelId = hotelId; }
        
        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        
        public Integer getCapacity() { return capacity; }
        public void setCapacity(Integer capacity) { this.capacity = capacity; }
        
        public Double getPricePerDay() { return pricePerDay; }
        public void setPricePerDay(Double pricePerDay) { this.pricePerDay = pricePerDay; }
        
        public java.util.List<String> getAmenities() { return amenities; }
        public void setAmenities(java.util.List<String> amenities) { this.amenities = amenities; }
    }
}
