# Hotel Management System - Microservices Architecture

A comprehensive hotel management system built with Spring Boot microservices, featuring service discovery, API gateway, and inter-service communication using Feign clients.

## Architecture Overview

The system is divided into the following microservices:

1. **Discovery Server (Eureka)** - Service registry and discovery
2. **API Gateway** - Central entry point with routing and CORS
3. **Catalog Service** - Manages hotels, room types, and rooms
4. **Booking Service** - Handles reservations and bookings
5. **User Service** - Manages user accounts and authentication

## Services Details

### 1. Discovery Server (Port: 8761)
- **Technology**: Spring Cloud Netflix Eureka Server
- **Purpose**: Service registry for all microservices
- **URL**: http://localhost:8761

### 2. API Gateway (Port: 8088)
- **Technology**: Spring Cloud Gateway
- **Purpose**: Central routing and CORS handling
- **Features**:
  - Routes requests to appropriate services
  - CORS configuration for Angular frontend
  - Load balancing with service discovery

**Routes**:
- `/api/admin/**` → Catalog Service
- `/api/booking/**` → Booking Service  
- `/api/user/**` → User Service

### 3. Catalog Service (Port: 8092)
- **Technology**: Spring Boot + JPA + H2
- **Purpose**: Manages hotel inventory
- **Entities**:
  - **Hotel**: hotelId, name, city, address, status, rating, totalRooms, availableRooms
  - **RoomType**: roomTypeId, category, description, capacity, pricePerDay, amenities
  - **Room**: roomId, roomNumber, status, hotelId, roomTypeId, floorNumber, lastMaintenanceDate

**Hotel Status**: OPEN, CLOSED, UNDER_MAINTENANCE
**Room Status**: AVAILABLE, RESERVED, OCCUPIED, UNDER_MAINTENANCE

### 4. Booking Service (Port: 8093)
- **Technology**: Spring Boot + JPA + H2 + Feign
- **Purpose**: Handles reservations and bookings
- **Entities**:
  - **Booking**: bookingId, userId, hotelId, roomId, checkInDate, checkOutDate, status, totalAmount, paymentStatus, reservationDate

**Booking Status**: PENDING, CONFIRMED, CHECKED_IN, CHECKED_OUT, CANCELLED
**Payment Status**: PAID, UNPAID, REFUNDED

**Feign Clients**:
- `CatalogServiceClient` - Communicates with Catalog Service
- `UserServiceClient` - Communicates with User Service

### 5. User Service (Port: 8094)
- **Technology**: Spring Boot + JPA + H2
- **Purpose**: Manages user accounts
- **Entities**:
  - **User**: userId, fullName, email, phoneNumber, passwordHash, role, loyaltyPoints

**User Roles**: CUSTOMER, ADMIN, STAFF

## Database Configuration

All services use H2 in-memory databases with console enabled:

- **Catalog Service**: http://localhost:8092/h2
- **Booking Service**: http://localhost:8093/h2  
- **User Service**: http://localhost:8094/h2

**Database URLs**:
- Catalog: `jdbc:h2:mem:catalog`
- Booking: `jdbc:h2:mem:booking`
- User: `jdbc:h2:mem:user`

## State Transitions

### Room Status Flow
```
AVAILABLE → RESERVED → OCCUPIED → CLEANING → AVAILABLE
                ↓
         UNDER_MAINTENANCE
```

### Booking Status Flow
```
PENDING → CONFIRMED → CHECKED_IN → CHECKED_OUT
    ↓
CANCELLED
```

## API Endpoints

### Catalog Service (`/api/admin/`)
- `GET /hotels` - List all hotels
- `GET /hotels/{id}` - Get hotel by ID
- `POST /hotels` - Create hotel
- `PUT /hotels/{id}` - Update hotel
- `DELETE /hotels/{id}` - Delete hotel
- `GET /room-types` - List room types
- `GET /rooms` - List rooms

### Booking Service (`/api/booking/`)
- `GET /bookings` - List all bookings
- `GET /bookings/{id}` - Get booking by ID
- `POST /bookings` - Create booking
- `PUT /bookings/{id}` - Update booking
- `PUT /bookings/{id}/status` - Update booking status
- `PUT /bookings/{id}/payment` - Update payment status
- `DELETE /bookings/{id}` - Cancel booking

### User Service (`/api/user/`)
- `GET /users` - List all users
- `GET /users/{id}` - Get user by ID
- `POST /users` - Create user
- `PUT /users/{id}` - Update user
- `DELETE /users/{id}` - Delete user
- `GET /users/role/{role}` - Get users by role

## Running the Application

### Prerequisites
- Java 17+
- Maven 3.6+

### Start Services (in order)

1. **Discovery Server**:
   ```bash
   cd discovery-server
   mvn spring-boot:run
   ```

2. **API Gateway**:
   ```bash
   cd api-gateway
   mvn spring-boot:run
   ```

3. **Catalog Service**:
   ```bash
   cd catalog-service
   mvn spring-boot:run
   ```

4. **User Service**:
   ```bash
   cd user-service
   mvn spring-boot:run
   ```

5. **Booking Service**:
   ```bash
   cd booking-service
   mvn spring-boot:run
   ```

### Verify Services
- Eureka Dashboard: http://localhost:8761
- API Gateway: http://localhost:8088
- All services should be registered in Eureka

## Sample Data

The application initializes with sample data:

- **3 Hotels**: Grand Palace Hotel (Mumbai), Royal Garden Resort (Delhi), Seaside Paradise (Goa)
- **7 Users**: 1 Admin, 2 Staff, 4 Customers with loyalty points
- **6 Bookings**: Various statuses and payment states
- **Multiple Room Types**: Standard, Deluxe, Suite with different amenities
- **Multiple Rooms**: Different floors and statuses

## Inter-Service Communication

The Booking Service uses Feign clients to communicate with other services:

- **Catalog Service**: Validates hotels, rooms, and room types
- **User Service**: Validates user existence and retrieves user information

## CORS Configuration

The API Gateway is configured to allow requests from:
- Angular frontend: http://localhost:4200
- All HTTP methods: GET, POST, PUT, PATCH, DELETE, OPTIONS
- All headers and credentials

## Development Notes

- All services use Spring Boot 3.5.5
- Spring Cloud 2025.0.0 for microservices features
- H2 database for development and testing
- JPA/Hibernate for data persistence
- Feign for HTTP client communication
- Service discovery with Eureka
- Gateway routing with Spring Cloud Gateway

## Next Steps

1. **Frontend Integration**: Connect Angular frontend to API Gateway
2. **Authentication**: Implement JWT-based authentication
3. **Security**: Add security configurations
4. **Monitoring**: Add Spring Boot Actuator and monitoring
5. **Testing**: Add comprehensive unit and integration tests
6. **Docker**: Containerize all services
7. **Production Database**: Replace H2 with PostgreSQL/MySQL
