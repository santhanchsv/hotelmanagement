# Hotel Management System - Project Structure

## Complete Microservices Architecture

```
Hotel_Management_System 2/
├── discovery-server/                 # Eureka Service Registry (Port: 8761)
│   ├── src/main/java/com/ilpmum/discovery_server/
│   │   └── DiscoveryServerApplication.java
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
│
├── api-gateway/                     # Spring Cloud Gateway (Port: 8088)
│   ├── src/main/java/com/ilpmum/api_gateway/
│   │   └── ApiGatewayApplication.java
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
│
├── catalog-service/                 # Hotel & Room Management (Port: 8092)
│   ├── src/main/java/com/ilpmum/hotel/catalog_service/
│   │   ├── CatalogServiceApplication.java
│   │   ├── controller/
│   │   │   ├── HotelController.java
│   │   │   ├── RoomController.java
│   │   │   └── RoomTypeController.java
│   │   ├── model/
│   │   │   ├── Hotel.java
│   │   │   ├── RoomType.java
│   │   │   └── Room.java
│   │   ├── repo/
│   │   │   ├── HotelRepository.java
│   │   │   ├── RoomTypeRepository.java
│   │   │   └── RoomRepository.java
│   │   ├── service/
│   │   │   └── CatalogService.java
│   │   └── config/
│   │       └── DataInitializer.java
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
│
├── booking-service/                 # Reservation Management (Port: 8093)
│   ├── src/main/java/com/ilpmum/hotel/booking_service/
│   │   ├── BookingServiceApplication.java
│   │   ├── controller/
│   │   │   └── BookingController.java
│   │   ├── model/
│   │   │   └── Booking.java
│   │   ├── repo/
│   │   │   └── BookingRepository.java
│   │   ├── service/
│   │   │   └── BookingService.java
│   │   ├── client/
│   │   │   ├── CatalogServiceClient.java
│   │   │   └── UserServiceClient.java
│   │   └── config/
│   │       └── DataInitializer.java
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
│
├── user-service/                    # User Management (Port: 8094)
│   ├── src/main/java/com/ilpmum/hotel/user_service/
│   │   ├── UserServiceApplication.java
│   │   ├── controller/
│   │   │   └── UserController.java
│   │   ├── model/
│   │   │   └── User.java
│   │   ├── repo/
│   │   │   └── UserRepository.java
│   │   ├── service/
│   │   │   └── UserService.java
│   │   └── config/
│   │       └── DataInitializer.java
│   ├── src/main/resources/
│   │   └── application.properties
│   └── pom.xml
│
├── front-end/                       # Angular Frontend
│   └── hotel-app/
│       ├── src/app/
│       │   ├── features/admin/
│       │   │   ├── add-hotel/
│       │   │   ├── hotel-detail/
│       │   │   ├── hotel-edit/
│       │   │   ├── hotels-list/
│       │   │   ├── roomtype-add/
│       │   │   └── roomtype-list/
│       │   ├── models/
│       │   │   ├── hotel.ts
│       │   │   ├── room-type.ts
│       │   │   └── room.ts
│       │   └── services/
│       │       └── catalog.service.ts
│       └── package.json
│
├── start-services.sh               # Startup script
├── stop-services.sh                # Shutdown script
├── README.md                       # Main documentation
├── PROJECT_STRUCTURE.md            # This file
└── logs/                          # Service logs (created at runtime)
```

## Service Dependencies

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   API Gateway   │    │ Discovery Server│    │  Catalog Service│
│   (Port: 8088)  │◄───┤   (Port: 8761)  ├───►│   (Port: 8092)  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│ Booking Service │    │  User Service   │    │   H2 Database   │
│  (Port: 8093)   │    │  (Port: 8094)   │    │   (In-Memory)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │
         │                       │
         ▼                       ▼
┌─────────────────┐    ┌─────────────────┐
│   H2 Database   │    │   H2 Database   │
│   (In-Memory)   │    │   (In-Memory)   │
└─────────────────┘    └─────────────────┘
```

## Data Flow

1. **Frontend** → **API Gateway** → **Service Discovery** → **Target Service**
2. **Booking Service** → **Feign Client** → **Catalog Service** (for room validation)
3. **Booking Service** → **Feign Client** → **User Service** (for user validation)

## Key Features Implemented

### ✅ Microservices Architecture
- Service discovery with Eureka
- API Gateway with routing
- Inter-service communication with Feign

### ✅ Data Models
- **Hotel**: Complete hotel information with status management
- **RoomType**: Room categories with amenities
- **Room**: Individual rooms with status tracking
- **User**: User management with roles and loyalty points
- **Booking**: Reservation management with status flow

### ✅ State Transitions
- **Room Status**: AVAILABLE → RESERVED → OCCUPIED → CLEANING → AVAILABLE
- **Booking Status**: PENDING → CONFIRMED → CHECKED_IN → CHECKED_OUT
- **Hotel Status**: OPEN, CLOSED, UNDER_MAINTENANCE

### ✅ Business Logic
- Room availability checking
- Booking conflict detection
- Loyalty points management
- Payment status tracking
- Maintenance scheduling

### ✅ Database Integration
- H2 in-memory databases for all services
- H2 console enabled for testing
- JPA/Hibernate for data persistence
- Sample data initialization

### ✅ API Endpoints
- RESTful APIs for all entities
- CRUD operations
- Status updates
- Search and filtering

### ✅ Error Handling
- Proper HTTP status codes
- Validation error messages
- Service communication error handling

## Next Steps for Frontend Integration

1. **Update Angular Services**: Modify existing services to use API Gateway endpoints
2. **Add New Models**: Create models for User and Booking entities
3. **Create New Components**: Build booking and user management components
4. **Update Routing**: Add routes for new features
5. **Authentication**: Implement login/logout functionality

## Testing the Backend

1. Start all services using `./start-services.sh`
2. Check Eureka dashboard: http://localhost:8761
3. Test API endpoints through API Gateway: http://localhost:8088
4. Use H2 consoles for database inspection
5. Verify inter-service communication through booking creation

The backend is now fully functional and ready for frontend integration!
